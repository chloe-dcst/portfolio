import json
import pandas as pd
import plotly.express as px
import re  

# Charger les fichiers
geojson_path = "./L_H/neighbourhoods.geojson"
csv_path = "./listings.csv"

with open(geojson_path, "r", encoding="utf-8") as f:
    neighbourhood = json.load(f)

df = pd.read_csv(csv_path, dtype={"id": str})

# Vérifier que les colonnes existent
if "room_type" in df.columns and "neighbourhood" in df.columns:
    df_counts = df.groupby(["neighbourhood", "room_type"]).size().reset_index(name="count")
    df_total = df.groupby("neighbourhood").size().reset_index(name="total_count")

    df_merge = pd.merge(df_counts, df_total, on="neighbourhood", how="left")
    df_merge["proportion"] = df_merge["count"] / df_merge["total_count"] * 100

    # Choisir une couleur pour chaque type de logement
    color_map = {
        "Entire home/apt": "Blues",
        "Private room": "Greens",
        "Shared room": "Oranges",
        "Hotel room": "Reds"
    }

    # Générer une carte pour chaque type de logement
    for room_type in df_merge["room_type"].unique():
        df_filtered = df_merge[df_merge["room_type"] == room_type]

        # Définir une échelle adaptée
        min_value = df_filtered["proportion"].min()
        max_value = df_filtered["proportion"].max()

        # Utiliser une échelle monochrome
        color_scale = color_map.get(room_type, "Greys")  # Défaut = Gris si inconnu

        fig = px.choropleth(df_filtered, 
                            geojson=neighbourhood, 
                            locations="neighbourhood", 
                            featureidkey="properties.neighbourhood",  
                            color="proportion",  
                            color_continuous_scale=color_scale,  # 🌈 Échelle monochrome
                            range_color=(min_value, max_value),  
                            labels={'proportion': f'Proportion de {room_type} (%)'},
                            title=f"Répartition des {room_type} par quartier")

        fig.update_geos(fitbounds="locations", visible=False)
        fig.update_layout(margin={"r": 0, "t": 50, "l": 0, "b": 50})

        # Nettoyer le nom du fichier
        clean_room_type = re.sub(r'[^\w\-_]', '_', room_type)
        filename = f"./C_L/cartes/carte_{clean_room_type.lower()}.html"

        fig.write_html(filename)
        print(f"Carte sauvegardée sous '{filename}' (échelle : {min_value} - {max_value}, couleur : {color_scale})")

else:
    print("Les colonnes 'room_type' et 'neighbourhood' sont nécessaires dans le fichier listings.csv")
