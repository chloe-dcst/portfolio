import pandas as pd
import json

# Charger le fichier CSV
csv_file = "listings.csv"
df = pd.read_csv(csv_file)

# Sélectionner les colonnes utiles et convertir en JSON
df = df[['id','name', 'room_type', 'price', 'latitude', 'longitude', 'availability_365']]
df_json = df.to_json(orient="records", force_ascii=False)

# Générer un fichier JavaScript contenant les données
js_content = f"const listingsData = {df_json};"

# Écrire dans un fichier listings.js
with open("listings.js", "w", encoding="utf-8") as js_file:
    js_file.write(js_content)

print("✅ Fichier 'listings.js' généré avec succès !")
