let map = L.map('map').setView([48.8566, 2.3522], 12); 
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

let markersCluster = L.markerClusterGroup();

function countRoomTypes(data) {
    return data.reduce((acc, item) => {
        if (item.room_type) {
            acc[item.room_type] = (acc[item.room_type] || 0) + 1;
        }
        return acc;
    }, {});
}

function updateRoomTypePieCharts(data) {
    const roomTypeCount = countRoomTypes(data);
    const sortedRoomTypes = Object.entries(roomTypeCount).sort((a, b) => b[1] - a[1]);

    if (sortedRoomTypes.length === 0) {
        console.warn("Aucun logement ne correspond aux filtres.");
        return;
    }

    const mainCategory = sortedRoomTypes[0];
    const otherCategories = sortedRoomTypes.slice(1);

    const trace1 = {
        labels: sortedRoomTypes.map(item => item[0]),
        values: sortedRoomTypes.map(item => item[1]),
        type: 'pie',
        textinfo: 'label+percent',
        hoverinfo: 'label+value+percent',
    };

    const trace2 = {
        labels: otherCategories.map(item => item[0]),
        values: otherCategories.map(item => item[1]),
        type: 'pie',
        textinfo: 'label+percent',
        hoverinfo: 'label+value+percent',
    };

    const layout = {
        title: 'Répartition des Logements',
        legend: {
            orientation: 'h',  // Légende horizontale en bas
            x: 0.5,            // Centré horizontalement
            xanchor: 'center', // Ancrage au centre
            y: -0.2,           // Positionner la légende en bas du graphique
            yanchor: 'bottom', // Ancrage en bas
        }
    };

    Plotly.react('room_type_chart_main', [trace1], layout);
    Plotly.react('room_type_chart_secondary', [trace2], layout);
}

function updatePriceChart(data) {
    if (data.length === 0) {
        console.warn("Aucun logement ne correspond aux filtres.");
        return;
    }

    const trace = {
        x: data.map(item => item.room_type),
        y: data.map(item => item.price),
        type: 'box',
        name: 'Prix',
    };

    const layout = {
        title: 'Distribution des Prix',
        xaxis: { title: 'Type de Logement' },
        yaxis: { title: 'Prix (€)' },
        legend: {
            orientation: 'h',
            x: 0.5,
            xanchor: 'center',
            y: -0.2,
            yanchor: 'bottom',
        }
    };

    Plotly.react('price_chart', [trace], layout);
}

function updateMap(data) {
    markersCluster.clearLayers();
    data.forEach(item => {
        if (item.latitude && item.longitude) {
            let logementNom = item.name ? item.name : "Nom inconnu";  // Si pas de nom, afficher "Nom inconnu"
            let logementType = item.room_type ? item.room_type : "Type inconnu";  // Si pas de type, afficher "Type inconnu"
            
            let marker = L.marker([item.latitude, item.longitude])
                .bindPopup(`<b>${logementNom}</b><br><i>Type:</i> ${logementType}<br><i>Prix:</i> ${item.price}€`);
            
            markersCluster.addLayer(marker);
        } else {
            console.warn("Coordonnées manquantes pour le logement:", item);
        }
    });
    map.addLayer(markersCluster);
}


function getMaxPrice(data) {
    return Math.max(...data.filter(item => item.price !== null).map(item => item.price));
}

function RoomTypeFilter() {
    const roomTypeFilter = document.getElementById('room_type_filter');
    const roomTypes = [...new Set(listingsData.map(item => item.room_type))].sort();

    roomTypeFilter.innerHTML = `<option value="">Tous</option>`; // Option "Tous"
    roomTypes.forEach(type => {
        roomTypeFilter.innerHTML += `<option value="${type}">${type}</option>`;
    });
}

function filterData() {
    const selectedRoomType = document.getElementById('room_type_filter').value;
    const minPrice = parseInt(document.getElementById('min_price_filter').value, 10);
    const maxPrice = parseInt(document.getElementById('max_price_filter').value, 10);

    const filteredData = listingsData.filter(item => 
        (selectedRoomType === "" || item.room_type === selectedRoomType) &&
        item.price !== null &&
        item.price >= minPrice &&
        item.price <= maxPrice
    );

    updateRoomTypePieCharts(filteredData);
    updatePriceChart(filteredData);
    updateMap(filteredData);
}

function initializeFilters() {
    RoomTypeFilter(); // Appelle cette fonction pour remplir le filtre
    const maxPrice = getMaxPrice(listingsData);
    document.getElementById('max_price_filter').value = maxPrice;
    document.getElementById('max_price_filter').max = maxPrice;
    filterData();
}

window.addEventListener('load', initializeFilters);

document.getElementById('min_price_filter').addEventListener('input', filterData);
document.getElementById('max_price_filter').addEventListener('input', filterData);
document.getElementById('room_type_filter').addEventListener('change', filterData);

window.addEventListener('load', filterData);
