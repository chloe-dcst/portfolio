import os
import json
import pandas as pd
import plotly.express as px

print("Répertoire de travail actuel :", os.getcwd(), 'L_H','cartes')

# os.makedirs("cartes", exist_ok=True)
output_dir = os.path.join(os.getcwd(), "L_H", "cartes")  # Assure-toi que ce dossier existe
os.makedirs(output_dir, exist_ok=True)  # Crée le dossier s'il n'existe pas

# Charger le fichier GeoJSON local
with open("./L_H/neighbourhoods.geojson", "r", encoding="utf-8") as f:
    neighbourhood = json.load(f)

# Charger le fichier CSV local
df = pd.read_csv("./listings.csv", dtype={"id": str})

print("Valeurs uniques dans listings.csv :", df["neighbourhood"].unique()[:10])  # Affiche les 10 premières valeurs
print("Valeurs uniques dans neighbourhoods.geojson :", 
      [feature["properties"].get("neighbourhood", "N/A") for feature in neighbourhood["features"][:10]])

print(df["price"].describe())  # Vérifie min, max et la présence de NaN
print("Nombre de features dans GeoJSON :", len(neighbourhood["features"]))

print(df["neighbourhood"].dtype)  # Doit être "object" (str)
print(type(neighbourhood["features"][0]["properties"]["neighbourhood"]))  # Doit être <class 'str'>

# Vérifier quelles valeurs sont en commun
csv_neighbourhoods = set(df["neighbourhood"].unique())
geojson_neighbourhoods = {feature["properties"]["neighbourhood"] for feature in neighbourhood["features"]}

# Afficher les quartiers présents dans le CSV mais absents du GeoJSON
print("Présents dans le CSV mais PAS dans le GeoJSON :", csv_neighbourhoods - geojson_neighbourhoods)
print("Présents dans le GeoJSON mais PAS dans le CSV :", geojson_neighbourhoods - csv_neighbourhoods)

print(df[["neighbourhood", "price"]].head())  # Vérifie que les données existent

# Créer une carte choroplèthe avec la couleur basée sur les prix
fig = px.choropleth(df, 
                    geojson=neighbourhood, 
                    locations="neighbourhood", 
                    featureidkey="properties.neighbourhood",  # Correspondance avec le GeoJSON
                    color="price",  # Utilise "price" comme couleur
                    color_continuous_scale="Viridis",  # L'échelle de couleurs (tu peux aussi tester d'autres comme RdYlGn)
                    range_color=(0, 200),  # Limiter la plage de couleurs de 0 à 200
                    labels={'price': 'Prix moyen'})

# Ajuster la carte pour qu'elle corresponde aux données
fig.update_geos(fitbounds="locations", visible=False)

fig.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})

# Enregistrer la carte dans un fichier HTML
fig.write_html(os.path.join(output_dir, "carte_interactive.html"))

print("Carte sauvegardée sous 'carte_interactive.html'")


# Compter le nombre de logements par quartier
df_counts = df["neighbourhood"].value_counts().reset_index()
df_counts.columns = ["neighbourhood", "count"]  # Renommer les colonnes

# Créer une carte choroplèthe pour le nombre de logements
fig_count = px.choropleth(df_counts, 
                          geojson=neighbourhood, 
                          locations="neighbourhood", 
                          featureidkey="properties.neighbourhood",  
                          color="count",  
                          color_continuous_scale="Blues",  
                          range_color=(0, df_counts["count"].max()),  
                          labels={'count': 'Nombre de logements'})

# Ajuster la carte
fig_count.update_geos(fitbounds="locations", visible=False)
fig_count.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})

# Enregistrer et afficher la carte
fig_count.write_html(os.path.join(output_dir, "carte_nombre_logements.html"))
print("Carte sauvegardée sous 'carte_nombre_logements.html'")




# Filtrer les logements entiers (en supposant qu'il existe une colonne "room_type" dans le CSV)
df_entiers = df[df["room_type"] == "Entire home/apt"]

# Calculer la part des logements entiers par quartier
df_entiers_counts = df_entiers["neighbourhood"].value_counts().reset_index()
df_entiers_counts.columns = ["neighbourhood", "count_entiers"]

# Calculer le nombre total de logements par quartier (même si déjà calculé précédemment)
df_total_counts = df["neighbourhood"].value_counts().reset_index()
df_total_counts.columns = ["neighbourhood", "count_total"]

# Fusionner les deux DataFrames sur la colonne "neighbourhood"
df_merge = pd.merge(df_total_counts, df_entiers_counts, on="neighbourhood", how="left")

# Calculer la part des logements entiers
df_merge["part_entiers"] = df_merge["count_entiers"] / df_merge["count_total"] * 100  # En pourcentage

# Créer une carte choroplèthe pour la part des logements entiers
fig_entiers = px.choropleth(df_merge, 
                            geojson=neighbourhood, 
                            locations="neighbourhood", 
                            featureidkey="properties.neighbourhood",  
                            color="part_entiers",  
                            color_continuous_scale="YlGnBu",  
                            range_color=(70, 100),  
                            labels={'part_entiers': 'Part des logements entiers (%)'})

# Ajuster la carte
fig_entiers.update_geos(fitbounds="locations", visible=False)
fig_entiers.update_layout(margin={"r": 0, "t": 0, "l": 0, "b": 0})

# Enregistrer et afficher la carte
fig_entiers.write_html(os.path.join(output_dir, "carte_part_logements_entiers.html"))
print("Carte sauvegardée sous 'carte_part_logements_entiers.html'")



