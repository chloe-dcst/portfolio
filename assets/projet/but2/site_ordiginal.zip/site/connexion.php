<?php
    try
    {	$connexion =  new PDO('mysql:host=localhost;dbname=ordiginal;charset=utf8', 'root', '');
    }
    catch (Exception $e)
    {	//affiche un message d'erreur et arr�te le processus
        die ('Erreur' . $e->getMessage());
    }
?>