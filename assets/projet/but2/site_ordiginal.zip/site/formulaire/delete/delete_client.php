<!DOCTYPE html>
<html lang="fr">
<!-- Fomulaire et PHP pour supprimer un client de la base -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./../../css/style.css">
    <title>Ordiginal</title>
</head>

<body>

    <header class="header">
        <a href="./../../index.html">
            <img class="logo" src="./../../logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./../../page/login/profil.html">Profil</a></li>
                <li><a href="./../../page/insertion.html">Insérer</a></li>
                <li><a href="./../../page/modification.html">Modifier</a></li>
                <li><a href="./../../page/supprimer.html">Supprimer</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li>Connecter</li>
            </ul>
        </nav>
    </header>
    <!-- formulaire pour choisir quel client -->
    <form method="post">
        <div id="formulaire">
            <fieldset>
                <h1>Supprimer un client</h1>
                <table>
                    <tr>
                        <td><label>ID Nom prénom *:</label></td>
                        <td>
                            <!-- liste déroulant avec l'id_client, le nom et le prénom du client qu'on souhaite supprimer -->
                            <select name="idClient" size="1">
                                <option value="" disabled selected>Choisissez une option</option>
                                <?php
                                // connexion à la base de données
                                include("../../connexion.php");
                                // requête pour récupérer les clients présents dans la base
                                $requete = "SELECT * FROM clients";
                                $resultat = $connexion->query($requete);
                                // afficher l'id, le nom et prénom dans la liste
                                while ($ligne = $resultat->fetch()) {
                                    echo "<option value='" . htmlspecialchars($ligne['id_client']) . "'>" . htmlspecialchars($ligne['id_client']) . " " . htmlspecialchars($ligne['nom']) . " " . htmlspecialchars($ligne['prenom']) . "</option>";
                                }
                                // fermeture de la connexion à la base
                                $connexion = null;
                                ?>
                            </select>
                        </td>
                    </tr>
                </table>
                <input type="submit" name="delete_client" value="Enregistrer">
            </fieldset>
        </div>
    </form>
    </br>
    <div>
        <!-- supprimer le client choisi -->
        <?php
        // connexion à la base
        include("../../connexion.php");
        // vérification que le formulaire n'est pas vide (qu'un client a bien été choisi)
        if (isset($_POST['delete_client'])) {
            $idClient = $_POST['idClient'];
            // requête pour supprimer le client
            $req = "DELETE from clients
                    WHERE id_client = '$idClient'";

            $ok = $connexion->exec($req);
            // message en fonction de ce qu'il se passe (fonctionne ou pas)
            if ($ok) {
                echo "Le client a bien été supprimé.";
            } else {
                echo "La suppression a échoué !";
            }
            // fermetuire de la connexion à la base
            $connexion = null;
        }
        ?>
    </div>

</body>

</html>