<!DOCTYPE html>
<html lang="fr">
<!-- formulaire PHP pour supprimer une commande de la base -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./../../css/style.css">
    <title>Ordiginal</title>
</head>

<body>

    <header class="header">
        <a href="./../../index.html">
            <img class="logo" src="./../../logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./../../page/login/profil.html">Profil</a></li>
                <li><a href="./../../page/insertion.html">Insérer</a></li>
                <li><a href="./../../page/modification.html">Modifier</a></li>
                <li><a href="./../../page/supprimer.html">Supprimer</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li>Connecter</li>
            </ul>
        </nav>
    </header>
    <!-- formulaire pour choisir la commande à supprimer -->
    <form method="post">
        <div id="formulaire">
            <fieldset>
                <h1>Supprimer une commande</h1>
                <table>
                    <tr>
                        <td><label>Numéro de commande *:</label></td>
                        <td>
                            <!-- Liste pour chosir le numéro de la commande -->
                            <select name="idCommande" size="1">
                                <option value="" disabled selected>Choisissez une option</option>
                                <?php
                                //ouverture de la connexion à la base de données
                                include("../../connexion.php");
                                // requête pour récupérer toutes les commandes présentes dans la base
                                $requete = "SELECT * FROM commande";
                                $resultat = $connexion->query($requete);
                                // affiche le numéro (Id) de la commande 
                                while ($ligne = $resultat->fetch()) {
                                    echo "<option value='" . addslashes($ligne['id_commande']) . "'>" . addslashes($ligne['id_commande']) . " </option>";
                                }
                                //fermeture de la connexion
                                $connexion = null;
                                ?>
                            </select>
                        </td>
                    </tr>

                </table>
                <input type="submit" name="delete_commande" value="Enregistrer">
            </fieldset>
        </div>
    </form>
    </br>
    <div>
        <!-- suppresion de la commande choisie -->
        <?php
        // ouverture de la connexion
        include("../../connexion.php");
        // vérification qu'une commande a été choisie pour la supprimer ensuite
        if (isset($_POST['delete_commande'])) {
            $idCommande = addslashes($_POST['idCommande']);
            // requête pour supprimer la commande choisie
            $req = "DELETE from commande 
                    WHERE id_commande = '$idCommande'";

            $ok = $connexion->exec($req);
            // affiche le message en fonction de si la suppresion a fonctionné ou non
            if ($ok) {
                echo "La commande a été supprimée.";
            } else {
                echo "La suppression a échoué !";
            }
            // fermeutre de la connexion
            $connexion = null;
        }
        ?>
    </div>

</body>

</html>