<!DOCTYPE html>
<html lang="fr">
<!-- Formulaire et PHP pour supprimer un ordinateur de la base -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./../../css/style.css">
    <title>Ordiginal</title>
</head>

<body>

    <header class="header">
        <a href="./../../index.html">
            <img class="logo" src="./../../logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./../../page/login/profil.html">Profil</a></li>
                <li><a href="./../../page/insertion.html">Insérer</a></li>
                <li><a href="./../../page/modification.html">Modifier</a></li>
                <li><a href="./../../page/supprimer.html">Supprimer</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li>Connecter</li>
            </ul>
        </nav>
    </header>

    <!-- Formulaire pour choisir la référence de 'ordinateur que l'on souhaite supprimer -->
    <form method="post">
        <div id="formulaire">
            <fieldset>
                <h1>Supprimer un ordinateur</h1>
                <table>
                    <tr>
                        <td><label>Référence *:</label></td>
                        <td>
                            <!-- Liste déroulante pour choisir la référence de l'ordinateur -->
                            <select name="ref" size="1">
                                <option value="" disabled selected>Choisissez une option</option>
                                <?php
                                // ouverture ded la connexion à la base
                                include("../../connexion.php");
                                //requête pour récupéré tous les ordinateurs présents dans la base
                                $requete = "SELECT * FROM ordinateur";
                                $resultat = $connexion->query($requete);
                                // affiche la référence de l'ordinateur dans la liste déroulante 
                                while ($ligne = $resultat->fetch()) {
                                    echo "<option value='" . htmlspecialchars($ligne['ref']) . "'>" . htmlspecialchars($ligne['ref']) . "</option>";
                                }
                                // fermeture de la connexion 
                                $connexion = null;
                                ?>
                            </select>
                        </td>
                    </tr>

                </table>

                <input type="submit" name="delete_ordi" value="Enregistrer">
            </fieldset>
        </div>
    </form>
    </br>
    <div>
        <!-- suppresion de l'ordinateur choisi -->
        <?php
        // connexion à la base 
        include("../../connexion.php");
        // vérification qu'une référence d'odinateur a été choisi
        if (isset($_POST['delete_ordi'])) {
            $refOrdi = $_POST['ref'];
            // requête pour réaliser la suppresion 
            $req = "DELETE from ordinateur
                    WHERE ref = '$refOrdi'";

            $ok = $connexion->exec($req);
            // afficher une message en fonction de c"e qui s'est passée 
            if ($ok) {
                echo "L'ordinateur a bien été supprimé.";
            } else {
                echo "La suppresion a échoué !";
            }
            // fermeture de la connexion à la base 
            $connexion = null;
        }
        ?>
    </div>

</body>

</html>