<html>
<meta charset="utf-8" lang="fr">
<!-- Php pour ajouter un avis  -->

<head>
	<title>Ajout d'un avis</title>
</head>

<body>
	<?php
	// connexion à la base
	include("./../../connexion.php");
	// Récupération de ce qui a été remplis dans le formulaire dans des variable 
	$client = $_POST['Client'];
	$commande = $_POST['Commande'];
	$ref = $_POST['ref'];
	$satisfaction = $_POST['satisfaction'];

	// test si la commande est du numérique
	if (!ctype_digit($commande))
		echo 'Attention, vous ne devez saisir que des chiffres pour le prix minimum';
	else {
		// requête "insert into" pour insérer le nouveau avis dans la table avis
		$requete = "insert into avis values (' " . addslashes($client) . " ', ' " . addslashes($commande) . " ','" . addslashes($ref) . " ','" . addslashes($satisfaction) . "')";
		$ok = $connexion->exec($requete);
		// Vérification du bon fonctionnement de la requête et donc affiche un message en fonction
		if ($ok == 1)
			echo "L'avis est ajouté.";
		else
			echo "Attention, l'ajout de l'avis a échoué !!!";
	}
	// fermeture de la connexion
	$connexion = null;
	?>
</body>

</html>