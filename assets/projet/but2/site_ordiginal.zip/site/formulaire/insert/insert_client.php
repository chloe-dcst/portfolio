<html>
<meta charset="utf-8" lang="fr">
<!-- Php pour ajouter un client  -->

<head>
    <title>Ajout d'un client</title>
</head>

<body>
    <?php
    // connexion à la base de données
    include("./../../connexion.php");
    // Récupération de ce qui a été remplis dans le formulaire dans des variable 
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $ville = $_POST['ville'];
    $codePostal = $_POST['cp'];
    $rue = $_POST['rue'];
    $tel = $_POST['tel'];
    $email = $_POST['email'];
    // écriture de la requête "insert into" pour ajouter un client 
    $requete = "Insert into clients (nom, prenom, ville, code_postal, rue, numero_telephone, adresse_mail) value ('" . addslashes($nom) . "','" . addslashes($prenom) . "',
            '" . addslashes($ville) . "','" . addslashes($codePostal) . "', '" . addslashes($rue) . "','" . $tel . "','" . $email . "')";
    echo $requete;
    $ok = $connexion->exec($requete);
    // Vérification du bon fonctionnement de la requête et donc affiche un message en fonction
    if ($ok == 1) {
        echo "L'enregistrement a bien été réalisé.";
    } else {
        echo "L'enregistrement a échoué";
    }
    // fermeture de la connexion
    $connexion = null;
    ?>
</body>

</html>