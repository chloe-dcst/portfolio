<html>
<meta charset="utf-8" lang="fr">
<!-- Php pour insérer une commande à la table commande -->
<head>
    <title>Ajout d'une commande</title>
</head>

<body>
    <?php
    // connexion à la base de données
    include("./../../connexion.php");
    // Récupération de ce qui a été remplis dans le formulaire dans des variables 
    $idClient = $_POST['id_client'];
    $refOrdi = $_POST['ref_ordi'];
    $quantite = $_POST['qte'];
    $date = $_post['date'];
    // écriture de la requête "insert into" pour ajouter une commande
    $requete = "Insert into commande (id_client, ref, quantite, date) value ('" . addslashes($idClient) . "','" . $refOrdi . "',
            '" . addslashes($quantite) . "','" . $date . "')";
    $ok = $connexion->exec($requete);
    // vérification de la requête et affiche un message en fonction 
    if ($ok == 1) {
        echo "L'enregistrement a bien été réalisé.";
    } else {
        echo "L'enregistrement a échoué";
    }
    // fermeture de la connexion
    $connexion=null;
    ?>
</body>

</html>