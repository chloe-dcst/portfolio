<html>
<meta charset="utf-8" lang="fr">
<!-- Php pour ajouter un ordinateur à la base -->
<head>
    <title>Ajout d'une commande</title>
</head>

<body>
    <?php
    // connexion à la base de données 
    include("./../../connexion.php");
    // récupération de ce qui a été rentrer dans le formulaire dans des variables
    $marque = $_POST['marque'];
    $refOrdi = $_POST['refordi'];
    if (empty($_POST['gaming'])) {  // si chekbox cocher afficher O sinon n
        $gaming = "n";
    } else {
        $gaming = "o";
    }
    $game = $_POST['game'];
    $sysExploit = $_POST['sysexploit'];
    $tailleEcran = $_POST['taille_ecran'];
    $resolEcran = $_POST['resolution_ecran'];
    $autonomie = $_POST['autonomie'];
    $stockage = $_POST['stockage'];
    $marqueCPU = $_POST['marque_cpu'];
    $refCPU = $_POST['ref_cpu'];
    $GPU = $_POST['gpu'];
    $RAM = $_POST['ram'];
    $prix = $_POST['prix'];
    // écriture de la requpete SQL "insert into"
    $requete = "Insert into ordinateur (ref, prix, marque, game, gaming, sys_exploit, taille_ecran, resolution_ecran, autonomie, stockage, CPU_marque, CPU_ref, GPU, RAM)
             value ('" . $refOrdi . "','" . $prix . "','" . addslashes($marque) . "','" . addslashes($game) . "', '" . addslashes($gaming) . "','" . addslashes($sysExploit) . "','" . $tailleEcran . "',
             '" . $resolEcran . "','" . addslashes($autonomie) . "','" . addslashes($stockage) . "','" . addslashes($marqueCPU) . "','" . $refCPU . "','" . $GPU . "','" . addslashes($RAM) . "')";
    $ok = $connexion->exec($requete);
    // vérification de la requête et affiche une phrase en fonction 
    if ($ok == 1) {
        echo "L'enregistrement a bien été réalisé.";
    } else {
        echo "L'enregistrement a échoué";
    }
    // fermeture de la connexion à la base de données 
    $connexion=null;
    ?>
</body>

</html>