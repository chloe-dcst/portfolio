<!DOCTYPE html>
<html lang="fr">
<!-- Formulaire et PHP pour modifier les information d'un client dans la base -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./../../css/style.css">
    <title>Ordiginal</title>
</head>

<body>

    <header class="header">
        <a href="./../../index.html">
            <img class="logo" src="./../../logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./../../page/login/profil.html">Profil</a></li>
                <li><a href="./../../page/insertion.html">Insérer</a></li>
                <li><a href="./../../page/modification.html">Modifier</a></li>
                <li><a href="./../../page/supprimer.html">Supprimer</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li>Connecter</li>
            </ul>
        </nav>
    </header>

    <!-- formulaire pour chosir le client puis modifier ses informations -->
    <form method="post">
        <div id="formulaire">
            <fieldset>
                <h1>Modifier un client</h1>
                <table>
                    <tr>
                        <td><label>Nom prénom *:</label></td>
                        <td>
                    <!-- Liste déroulante pour choisir le client qu'on veut modifier  -->
                            <select name="idClient" size="1">
                                <option value="" disabled selected>Choisissez une option</option>
                                <?php
                                //Ouverture de la connexion 
                                include("../../connexion.php");
                                // requête pour récupéré tous les clients présents dans la base
                                $requete = "SELECT * FROM clients";
                                $resultat = $connexion->query($requete);
                                // Affiche le nom et le prénom du client que l'on souhaite modifier
                                while ($ligne = $resultat->fetch()) {
                                    echo "<option value='" . htmlspecialchars($ligne['id_client']) . "'>" . htmlspecialchars($ligne['nom']) . " " . htmlspecialchars($ligne['prenom']) . "</option>";
                                }
                                // fermeture de la connexion
                                $connexion = null;
                                ?>
                            </select>
                        </td>
                    </tr>
                    <!-- Formulaire pour modifier les infos  -->
                    <tr>
                        <td><label>Ville *:</label></td>
                        <td><input type="text" name="ville" size="15"></td>
                    </tr>
                    <tr>
                        <td><label>Code postal:</label></td>
                        <td><input type="text" name="cp" size="15"></td>
                    </tr>
                    <tr>
                        <td><label>Rue *:</label></td>
                        <td><input type="text" name="rue" size="30"></td>
                    </tr>
                    <tr>
                        <td><label>Numéro de téléphone (00/00/00/00/00) *:</label></td>
                        <td><input type="tel" name="tel" size="15"></td>
                    </tr>
                    <tr>
                        <td><label>Adresse mail *:</label></td>
                        <td><input type="email" name="email" size="15"></td>
                    </tr>
                </table>
                <input type="submit" name="update_client" value="Enregistrer">
            </fieldset>
        </div>
    </form>
    </br>
    <div>
        <!-- Effectuer les modifications -->
        <?php
        // ouverture de la connexion à la base
        include("../../connexion.php");
        // vérification qu'il y a des champs de remplis et les mettre dans une variable
        if (isset($_POST['update_client'])) {
            $idClient = $_POST['idClient'];
            $ville = addslashes($_POST['ville']);
            $codePostal = addslashes($_POST['cp']);
            $rue = addslashes($_POST['rue']);
            $tel = addslashes($_POST['tel']);
            $email = addslashes($_POST['email']);
            // requête pour réaliser les modifications
            $req = "UPDATE clients
                    SET ville = '$ville',
                        code_postal = '$codePostal',
                        rue = '$rue',
                        numero_telephone = '$tel',
                        adresse_mail = '$email'
                    WHERE id_client = '$idClient'";

            $ok = $connexion->exec($req);
            //Afficahe d'un message de réussite ou d'echec
            if ($ok) {
                echo "La mise à jour a bien été réalisée.";
            } else {
                echo "La mise à jour a échoué !";
            }
            // Fermeture de la connexion 
            $connexion = null;
        }
        ?>
    </div>

</body>

</html>