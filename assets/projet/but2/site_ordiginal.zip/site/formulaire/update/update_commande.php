<!DOCTYPE html>
<html lang="fr">
<!-- Formulaire et PHP pour modifier une commande -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./../../css/style.css">
    <title>Ordiginal</title>
</head>

<body>

    <header class="header">
        <a href="./../../index.html">
            <img class="logo" src="./../../logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./../../page/login/profil.html">Profil</a></li>
                <li><a href="./../../page/insertion.html">Insérer</a></li>
                <li><a href="./../../page/modification.html">Modifier</a></li>
                <li><a href="./../../page/supprimer.html">Supprimer</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li>Connecter</li>
            </ul>
        </nav>
    </header>

    <!-- Formulaire pour choisir la commmande puis modifier ses infos -->
    <form method="post">
        <div id="formulaire">
            <fieldset>
                <h1>Modifier une commande</h1>
                <table>
                    <!-- Liste déroulante pour shoir le numéro de la commande -->
                    <tr>
                        <td><label>Numéro de commande *:</label></td>
                        <td>
                            <select name="idCommande" size="1">
                                <option value="" disabled selected>Choisissez une option</option>
                                <?php
                                // ouverture de la connexion
                                include("../../connexion.php");
                                //requête poure récupéré toutes les commandes présentes dans la base
                                $requete = "SELECT * FROM commande";
                                $resultat = $connexion->query($requete);
                                // Affiche le numéro (Id) de la commande dans la liste
                                while ($ligne = $resultat->fetch()) {
                                    echo "<option value='" . addslashes($ligne['id_commande']) . "'>" . addslashes($ligne['id_commande']) . " </option>";
                                }
                                // fermeture de la connexion
                                $connexion = null;
                                ?>
                            </select>
                        </td>
                    </tr>

                    <!-- Formulaire pour modifier les infos de la commande choisie -->
                    <tr>
                        <td><label>Nom * :</label></td>
                        <td><input type="text" name="nom" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Prénom *:</label></td>
                        <td><input type="text" name="prenom" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Référence ordinateur *:</label></td>
                        <td><input type="text" name="ref_ordi" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Quantité *:</label></td>
                        <td><input type="text" name="qte" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Date *:</label></td>
                        <td><input type="date" name="date" size="15"></td>
                    </tr>

                </table>
                <input type="submit" name="update_commande" value="Enregistrer">
            </fieldset>
        </div>
    </form>
    </br>
    <div>
        <!-- Modification des infos -->
        <?php
        // ouverture de la connexion
        include("../../connexion.php");
        // vérifier que les champs ne sont pas vides et les affecter à une variable
        if (isset($_POST['update_commande'])) {
            $idCommande = addslashes($_POST['idCommande']);
            $nom = addslashes($_POST['nom']);
            $prenom = addslashes($_POST['prenom']);
            $refOrdi = addslashes($_POST['ref_ordi']);
            $quantite = addslashes($_POST['qte']);
            $date = $_POST['date'];

            // requête pour récupéré l'id_client correspond au nom prénom du client rentrer dans le formulaire
            $requete = "SELECT id_client from clients where nom = '$nom' and prenom = '$prenom' ";
            $resultat = $connexion->query($requete);
            $idClient = $resultat->fetch()['id_client'];
            // requête pour effectuer les modifications
            $req = "UPDATE commande
                    SET id_client = '$idClient',
                        ref = '$refOrdi',
                        quantite = '$quantite'
                        -- date = '$date' fonctionne pas car la colonne dans la tables est 'date'
                    WHERE id_commande = '$idCommande'";
            $ok = $connexion->exec($req);

            // message d'erreur ou de réussite
            if ($ok) {
                echo "La mise à jour a bien été réalisée.";
            } else {
                echo "La mise à jour a échoué !";
            }
            //fermeture de la connexion
            $connexion = null;
        }
        ?>
    </div>

</body>

</html>