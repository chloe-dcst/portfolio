<!DOCTYPE html>
<html lang="fr">
<!-- Formulaire et PHP pour modifer les infos d'un ordinateur dans la base -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./../../css/style.css">
    <title>Ordiginal</title>
</head>

<body>

    <header class="header">
        <a href="./../../index.html">
            <img class="logo" src="./../../logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./../../page/login/profil.html">Profil</a></li>
                <li><a href="./../../page/insertion.html">Insérer</a></li>
                <li><a href="./../../page/modification.html">Modifier</a></li>
                <li><a href="./../../page/supprimer.html">Supprimer</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li>Connecter</li>
            </ul>
        </nav>
    </header>
    <!-- Formulaire pour chosir l'ordi et faire les modif -->
    <form method="post">
        <div id="formulaire">
            <fieldset>
                <h1>Modifier un ordinateur</h1>
                <table>
                    <!-- Liste déroulante pour choisir l'ordinateur -->
                    <tr>
                        <td><label>Référence *:</label></td>
                        <td>
                            <select name="ref" size="1">
                                <option value="" disabled selected>Choisissez une option</option>
                                <?php
                                // Ouverture de la connexion
                                include("../../connexion.php");
                                // requête pour récupéré toutes les références d'ordinateurs présents dans la base
                                $requete = "SELECT * FROM ordinateur";
                                $resultat = $connexion->query($requete);
                                // Afficher la ref de l'ordi dans la liste
                                while ($ligne = $resultat->fetch()) {
                                    echo "<option value='" . htmlspecialchars($ligne['ref']) . "'>" . htmlspecialchars($ligne['ref']) . "</option>";
                                }
                                //fermeture de la connexion
                                $connexion = null;
                                ?>
                            </select>
                        </td>
                    </tr>
                    <!-- Formulaire poure effectuer les modifications -->
                    <tr>
                        <td><label>Marque *:</label></td>
                        <td><input type="text" name="marque" size="15"></td>
                    </tr>
                    <tr>
                        <td><label>Ordinateur gaming *:</label></td>
                        <td><input type="checkbox" name="gaming"></td>
                    </tr>

                    <tr>
                        <td><label>Game *:</label></td>
                        <td><input type="text" name="game" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Système d'exploitation *:</label></td>
                        <td><input type="text" name="sysexploit" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Taille de l'écran (en pouce) *:</label></td>
                        <td><input type="text" name="taille_ecran" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Résolution de l'écran *:</label></td>
                        <td><input type="text" name="resolution_ecran" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Autonomie (en heure) :</label></td>
                        <td><input type="text" name="autonomie" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Stockage *:</label></td>
                        <td><input type="text" name="stockage" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Marque du CPU *:</label></td>
                        <td><input type="text" name="marque_cpu" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Référence CPU *:</label></td>
                        <td><input type="text" name="ref_cpu" size="25"></td>
                    </tr>

                    <tr>
                        <td><label>GPU *:</label></td>
                        <td><input type="text" name="gpu" size="25"></td>
                    </tr>

                    <tr>
                        <td><label>RAM *:</label></td>
                        <td><input type="text" name="ram" size="15"></td>
                    </tr>

                    <tr>
                        <td><label>Prix *:</label></td>
                        <td><input type="text" name="prix" size="10"></td>
                    </tr>

                </table>

                <input type="submit" name="update_ordi" value="Enregistrer">
            </fieldset>
        </div>
    </form>
    </br>
    <div>
        <!-- effecteur les modifications -->
        <?php
        // ouverture de la connexion
        include("../../connexion.php");

        // Vérifier que des champs sont remplis
        if (isset($_POST['update_ordi'])) {
            $marque = $_POST['marque'];
            $refOrdi = $_POST['ref'];
            if (empty($_POST['gaming'])) {  // si chekbox cocher afficher O sinon n
                $gaming = "n";
            } else {
                $gaming = "o";
            }
            $game = $_POST['game'];
            $sysExploit = $_POST['sysexploit'];
            $tailleEcran = $_POST['taille_ecran'];
            $resolEcran = $_POST['resolution_ecran'];
            $autonomie = $_POST['autonomie'];
            $stockage = $_POST['stockage'];
            $marqueCPU = $_POST['marque_cpu'];
            $refCPU = $_POST['ref_cpu'];
            $GPU = $_POST['gpu'];
            $RAM = $_POST['ram'];
            $prix = $_POST['prix'];

            // requête pour effectuer les modifications
            $req = "UPDATE ordinateur
                    SET prix = '$prix',
                        marque = '$marque',
                        game = '$game',
                        gaming = '$gaming',
                        sys_exploit = '$sysExploit',
                        taille_ecran = '$tailleEcran',
                        resolution_ecran = '$resolEcran',
                        autonomie = '$autonomie',
                        stockage = '$stockage',
                        CPU_marque = '$marqueCPU',
                        CPU_ref = '$refCPU',
                        GPU = '$GPU', 
                        RAM = '$RAM'
                    WHERE ref = '$refOrdi'";

            $ok = $connexion->exec($req);

            //message de réussite ou d'erreur
            if ($ok) {
                echo "La mise à jour a bien été réalisée.";
            } else {
                echo "La mise à jour a échoué !";
            }
            // fermeture de la connexion 
            $connexion = null;
        }
        ?>
    </div>

</body>

</html>