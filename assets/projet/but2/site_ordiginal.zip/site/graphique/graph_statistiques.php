<html lang="fr">
<head>
    <!-- Liens obligatoires pour invoquer jQuery et HighCharts, ces fichiers peuvent être récupérés en local -->
    <script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="http://code.highcharts.com/highcharts.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="./../css/style.css">
    <title>Ordiginal</title>
</head>

    <body>
    <header class="header">
        <a href="./../index.php">
            <img class="logo" src="./../logo.jpg" alt="logo">
        </a>            
        <nav class="nav-links">  
                <ul>
                    <li><a href="./../index.php">Accueil</a></li>
                    <li><a href="./../page/recherche.php">Recherche</a></li>
                    <li><a href="./../page/commander.html">Commander</a></li>
                    <li><a href="./../page/avis.html">Avis</a></li>
                    <li><a href="./graph_statistiques.php">Statistiques</a></li>
                </ul>
            </nav>
            <nav class="lien-connect">
                <ul>
                    <li><a href="./../page/login/identification.html">Se connecter</a></li>
                </ul>
            </nav>
                        
        </header>
        <h1>Quelques chiffres</h1>
        
<form method="post">
    <label for="annee">Choisissez une année :</label>
    <select name="annee" id="annee">
    <?php
        // Connexion à la base de données et remplissage des options (votre code existant ici)
        include("./../connexion.php");

         // création d'une nouvelle colonne dans ma table commande qui récupère seulement  l'année de ma date
        try {
            $sql = "ALTER TABLE commande
                ADD annee VARCHAR(7) GENERATED ALWAYS AS (DATE_FORMAT(date, '%Y')) STORED;";

            // Exécution de la commande SQL
            $connexion->exec($sql);
        } catch (PDOException $e) {
            echo "Erreur : " . $e->getMessage();
        
        }

        try {
            $requete = "SELECT DISTINCT annee FROM commande ORDER BY annee ASC";
            $resultat = $connexion->query($requete);

            while ($ligne = $resultat->fetch(PDO::FETCH_ASSOC)) {
                echo "<option value='" . htmlspecialchars($ligne['annee']) . "'>" . htmlspecialchars($ligne['annee']) . "</option>";
            }
        } catch (PDOException $e) {
            echo "Erreur de connexion : " . $e->getMessage();
        }
        ?>
    </select></br></br>
    <input type="submit" value="Voir le résultat de cette année">
</form>
<?php
        // Connexion à la base de données
        include("./../connexion.php");

        $annee_selectionnee = '';
        if (isset($_POST['annee'])) {
            $annee_selectionnee = $_POST['annee'];
            echo " Nombre de commandes passées dans l'année " . htmlspecialchars($annee_selectionnee);
        }

        // création d'une nouvelle colonne dans ma table commande qui récupère seulement  le mois de ma date
    try {
        $sql = "ALTER TABLE commande
                ADD mois VARCHAR(7) GENERATED ALWAYS AS (DATE_FORMAT(date, '%m')) STORED;";

        // Exécution de la commande SQL
        $connexion->exec($sql);
    } catch (PDOException $e) {
        echo "Erreur : " . $e->getMessage();
    }

    // Récupération du nombre de commandes par mois et année selectionnée
    $requete = "SELECT count(*) As nbcommandejanv FROM commande where mois='01' AND annee= '" . $annee_selectionnee . "'";
    $query = $connexion->query($requete);
    $ligne = $query->fetch();
    $nbComjan = $ligne['nbcommandejanv'];

    $query = $connexion->query("SELECT count(*) As nbcommandefev FROM commande where mois='02' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComfe = $ligne['nbcommandefev'];

    $query = $connexion->query("SELECT count(*) As nbcommandemars FROM commande where mois='03' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbCommar = $ligne['nbcommandemars'];

    $query = $connexion->query("SELECT count(*) As nbcommandeavril FROM commande where mois='04' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComavr = $ligne['nbcommandeavril'];

    $query = $connexion->query("SELECT count(*) As nbcommandemai FROM commande where mois='05' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComma = $ligne['nbcommandemai'];

    $query = $connexion->query("SELECT count(*) As nbcommandejuin FROM commande where mois='06' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComju = $ligne['nbcommandejuin'];

    $query = $connexion->query("SELECT count(*) As nbcommandejuillet FROM commande where mois='07' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComjuil = $ligne['nbcommandejuillet'];

    $query = $connexion->query("SELECT count(*) As nbcommandeaout FROM commande where mois='08' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComaou = $ligne['nbcommandeaout'];

    $query = $connexion->query("SELECT count(*) As nbcommandesept FROM commande where mois='09' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComsep = $ligne['nbcommandesept'];

    $query = $connexion->query("SELECT count(*) As nbcommandeocto FROM commande where mois='10' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComoct = $ligne['nbcommandeocto'];

    $query = $connexion->query("SELECT count(*) As nbcommandenovemb FROM commande where mois='11' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComnov = $ligne['nbcommandenovemb'];

    $query = $connexion->query("SELECT count(*) As nbcommandedecemb FROM commande where mois='12' AND annee= '" . $annee_selectionnee . "'");
    $ligne = $query->fetch();
    $nbComdec = $ligne['nbcommandedecemb'];

// Récupération des nombres d'avis par satisfaction
    $requete = "SELECT count(*) As nbExcellent FROM avis where satisfaction='excellent'";
    $query = $connexion->query($requete);
    $ligne = $query->fetch();
    $nbComExcellent = $ligne['nbExcellent'];

    $query = $connexion->query("SELECT count(*) As nbTresBon FROM avis where satisfaction='très bon'");
    $ligne = $query->fetch();
    $nbComTresBon = $ligne['nbTresBon'];

    $query = $connexion->query("SELECT count(*) As nbNeutre FROM avis where satisfaction='neutre'");
    $ligne = $query->fetch();
    $nbComNeutre = $ligne['nbNeutre'];

    $query = $connexion->query("SELECT count(*) As nbMauvais FROM avis where satisfaction='mauvais'");
    $ligne = $query->fetch();
    $nbComMauvais = $ligne['nbMauvais'];

    $query = $connexion->query("SELECT count(*) As nbTresMauvais FROM avis where satisfaction='très mauvais'");
    $ligne = $query->fetch();
    $nbComTresMauvais = $ligne['nbTresMauvais'];

    // fermeture de la connexion
    $connexion = null;
    ?>

    <div id="graphique"></div>
    <script>
        // Création d’un graphique qui montre le nb de commande de l'année choisi précédement 
        $('#graphique').highcharts({
            chart: {
                type: 'column'
            }, // ou area, spline, line (par défaut) ou pie
            title: {
                text: 'Nombre de commande par mois'
            },
            xAxis: {
                categories: ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'aout', 'septembre', 'octobre', 'novembre', 'decembre']
            },
            yAxis: {
                title: {
                    text: 'nb commandes'
                }
            },

            // Les données de notre graphique
            series: [{
                name: 'commandes',
                // Essayer d’abord avec des données fixes pour voir si le graphique
                // s’affiche, par exemple :
                //data : [2,10,3,4,7]
                data: [<?php echo $nbComjan ?>, <?php echo $nbComfe ?>, <?php echo $nbCommar ?>, <?php echo $nbComavr ?>, <?php echo $nbComma ?>, <?php echo $nbComju ?>, <?php echo $nbComjuil ?>, <?php echo $nbComaou ?>, <?php echo $nbComsep ?>, <?php echo $nbComoct ?>, <?php echo $nbComnov ?>, <?php echo $nbComdec ?>]
            }]
        });
    </script>

    <div id="graphique2"></div>
    <script>
        // Création d’un graphique qui montre le nb d'avis par satisfaction
        $('#graphique2').highcharts({
            chart: {
                type: 'pie'
            }, // ou area, spline, line (par défaut) ou pie
            title: {
                text: 'Nombre de client par satisfaction'
            },
            xAxis: {
                categories: ['excellent', 'très bon', 'neutre', 'mauvais', 'très mauvais']
            },
            yAxis: {
                title: {
                    text: 'Effectif'
                }
            },

            // Les données de notre graphique
            series: [{
                name: 'Avis',
                data: [{ name: 'Excellent', y: <?php echo $nbComExcellent; ?> },
            { name: 'Très bon', y: <?php echo $nbComTresBon; ?> },
            { name: 'Neutre', y: <?php echo $nbComNeutre; ?> },
            { name: 'Mauvais', y: <?php echo $nbComMauvais; ?> },
            { name: 'Très mauvais', y: <?php echo $nbComTresMauvais; ?> }],
            color: '#007096',
            }]
        });
    </script>
</body>
</html>