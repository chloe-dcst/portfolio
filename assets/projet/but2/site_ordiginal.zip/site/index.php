<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/style.css">
    <title>Ordiginal</title>
</head>

<body>
    <!-- Barre de navigation -->
    <header class="header">
        <a href="./index.php">
            <img class="logo" src="logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./index.html">Accueil</a></li>
                <li><a href="./page/recherche.php">Recherche</a></li>
                <li><a href="./page/commander.html">Commander</a></li>
                <li><a href="./page/avis.html">Avis</a></li>
                <li><a href="./graphique/graph_statistiques.php">Statistiques</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li><a href="./page/login/identification.html">Se connecter</a></li>
            </ul>
        </nav>
    </header>

    <!-- Section d'accueil principale -->
    <section class="acceuil">
        <div class="presentation">
            <h1>Ordiginal</h1>
            <p>Chercher l'ordinateur qu'il vous faut au meilleur prix !</p>
            <p>Retrouvez directement toutes nos références ci-dessous ou recherchez un modèle spécifique selon vos
                besoins.</p>
            <a href="./page/recherche.php" class="cta-button">Recherche</a>
        </div>

        <!-- Carrousel pour la présentation de modèle prédéfinis -->
        <div class="carrousel-global">
            <div class="conteneur-ordi">
                <button class="nav-btn left-btn" onclick="prevSlide()">&#9664;</button>
                <div class="carrousel">
                    <?php
                    include("./connexion.php");

                    $reference = ["NX.AQ1EF.001", "FA506IC", "Latitude 3535"];
                    $emplacement = str_repeat('?,', count($reference) - 1) . '?';

                    $requete = "SELECT marque, game, image FROM ordinateur WHERE ref IN ($emplacement)";
                    $resultat = $connexion->prepare($requete);
                    $resultat->execute($reference);

                    while ($imageOrdi = $resultat->fetch(PDO::FETCH_ASSOC)) {
                        echo '<div class="carrousel-item">';
                        echo '<img src="data:image/jpeg;base64,' . base64_encode($imageOrdi['image']) . '" alt="Image Ordinateur">';
                        echo '<p>' . htmlspecialchars($imageOrdi['marque']) . ' - ' . htmlspecialchars($imageOrdi['game']) . '</p>';
                        echo '</div>';
                    }

                    $connexion = null;
                    ?>
                </div>
                <button class="nav-btn right-btn" onclick="nextSlide()">&#9654;</button>
            </div>
        </div>
    </section>

    <footer>
        Nous contacter :<br>
        Par mail : ordiginal@outlook.fr<br>
        Par téléphone : 07 55 62 17 23
    </footer>

    <!-- Code JS pour les fonctions de mouvement des images dans le carrousel -->
    <script>
        let currentSlide = 0;

        function showSlide(index) {
            const slides = document.querySelectorAll('.carrousel-item');
            const totalSlides = slides.length;

            currentSlide = (index + totalSlides) % totalSlides;

            const offset = -currentSlide * 100;
            document.querySelector('.carrousel').style.transform = `translateX(${offset}%)`;
        }

        function nextSlide() {
            showSlide(currentSlide + 1);
        }

        function prevSlide() {
            showSlide(currentSlide - 1);
        }
    </script>

</body>

</html>