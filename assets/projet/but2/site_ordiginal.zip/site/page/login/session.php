<?php
session_start();

// Informations de connexion à la base de données
$host = 'localhost';
$dbname = 'ordiginal';
$username = 'root';
$password = '';

// Nouvelle connexu=ion à la base de données
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

// Traitement de la connexion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usernameInput = $_POST['identifiant'];
    $passwordInput = $_POST['mdp'];

    // Requête pour vérifier l'utilisateur
    $query = "SELECT * FROM utilisateurs WHERE identifiant = :identifiant";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':identifiant', $usernameInput);
    $stmt->execute();

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Vérification directe sans hachage
    if ($user && $passwordInput === $user['mot_de_passe']) {
        // Stocker l'utilisateur dans la session
        echo "Connexion réussie. Redirection vers le profil...";
        $_SESSION['username'] = $user['identifiant'];
        header('Location: profil.html'); // Rediriger vers le blog
        exit;
    } else {
        echo $error = "Identifiant ou mot de passe incorrect.";
    }
}
