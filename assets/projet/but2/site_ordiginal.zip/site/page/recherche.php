<html lang="fr">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="./../css/style.css">
    <title>Recherche ordinateur</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.highcharts.com/highcharts.js"></script>
</head>

<body>
    <!-- Barre de navigation -->
    <header class="header">
        <a href="./../index.php">
            <img class="logo" src="./../logo.jpg" alt="logo">
        </a>
        <nav class="nav-links">
            <ul>
                <li><a href="./../index.php">Accueil</a></li>
                <li><a href="./recherche.php">Recherche</a></li>
                <li><a href="./commander.html">Commander</a></li>
                <li><a href="./avis.html">Avis</a></li>
                <li><a href="./../graphique/graph_statistiques.php">Statistiques</a></li>
            </ul>
        </nav>
        <nav class="lien-connect">
            <ul>
                <li><a href="./login/identification.html">Se connecter</a></li>
            </ul>
        </nav>
    </header>

    <div class="acceuil">
        <h1>Trouver votre machine !</h1>
        <p>Rechercher tous nos ordinateurs ou alors seulement certain correspondant à vos critères ; en selectionnant tous simplement les champs qui vous intéresse.</p>
    </div>

    <section class="conteneur-flex">

        <!-- Formulaire de recherche d'un ordinateur -->
        <form method="post">
            <section id="formulaire">
                <fieldset>
                    <h1>Recherche d'un ordinateur</h1>
                    <table>
                        <tr>
                            <td>Ordinateur gaming : </td>
                            <td><input type="checkbox" name="gaming"></td>
                        </tr>

                        <!-- Marque -->
                        <tr>
                            <td>Marque : </td>
                            <td>
                                <select name="marque">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(marque) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['marque'] . "'>" . $ligne['marque'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- Game -->
                        <tr>
                            <td>Game : </td>
                            <td>
                                <select name="game">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(game) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['game'] . "'>" . $ligne['game'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- Système d'exploitation -->
                        <tr>
                            <td>Système d'exploitation : </td>
                            <td>
                                <select name="sys_exploit">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(sys_exploit) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['sys_exploit'] . "'>" . $ligne['sys_exploit'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- Taille d'écran -->
                        <tr>
                            <td>Taille d'écran : </td>
                            <td>
                                <select name="taille_ecran">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(taille_ecran) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['taille_ecran'] . "'>" . $ligne['taille_ecran'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- Marque du CPU -->
                        <tr>
                            <td>Marque CPU : </td>
                            <td>
                                <select name="CPU_marque">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(CPU_marque) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['CPU_marque'] . "'>" . $ligne['CPU_marque'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- Référence du CPU -->
                        <tr>
                            <td>Reférence CPU : </td>
                            <td>
                                <select name="CPU_ref">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(CPU_ref) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['CPU_ref'] . "'>" . $ligne['CPU_ref'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- Marque du GPU -->
                        <tr>
                            <td>Reférence GPU : </td>
                            <td>
                                <select name="GPU">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(GPU) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['GPU'] . "'>" . $ligne['GPU'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- RAM -->
                        <tr>
                            <td>RAM : </td>
                            <td>
                                <select name="RAM">
                                    <option value=""></option>
                                    <?php
                                    include("./../connexion.php");
                                    $requete = "select distinct(RAM) from ordinateur";
                                    $resultat = $connexion->query($requete);
                                    while ($ligne = $resultat->fetch()) {
                                        echo " <option value = '" . $ligne['RAM'] . "'>" . $ligne['RAM'] . "</option>";
                                    }
                                    $connexion = null;
                                    ?>
                                </select>
                            </td>
                        </tr>

                        <!-- Prix -->
                        <tr>
                            <td>Prix : </td>
                            <td><input type="text" name="prix"></td>
                        </tr>

                    </table>
                    <input type="submit" value="Rechercher" name="recherche">
                </fieldset>
            </section>
        </form>

        <!-- Graphique des ordinateurs vendus par marque -->
        <section class="graphe">
            <?php
            include('./../connexion.php');
            // récupérer le nb d'ordi vendu par marque
            $requete = "SELECT marque, count(commande.ref)  from commande inner join ordinateur on commande.ref = ordinateur.ref 
                Group by marque";
            $query = $connexion->query($requete);
            $ligne = $query->fetch();
            $i = 0;
            while ($ligne) {
                $tabMarque[$i] = $ligne['marque'];
                $tabEffectif[$i] = $ligne[1];
                $i++;
                $ligne = $query->fetch();
            }
            // fermeture de la connexion
            $connexion = null;
            ?>

            <div id="graphique"></div>
            <script>
                // Création d’un graphique qui montre le nb d'ordinateur acheté par marque
                $('#graphique').highcharts({
                    chart: {
                        type: 'column'
                    }, // peut être aussi area, spline, line (par défaut) ou pie
                    title: {
                        text: 'Nombre d\'ordinateurs acheté'
                    },
                    xAxis: {
                        categories: [<?php for ($i = 0; $i < count($tabMarque); $i++) echo "'" . $tabMarque[$i] . "',"; ?>]
                    },
                    yAxis: {
                        title: {
                            text: 'nombre d\'achat'
                        }
                    },
                    // Les données de notre graphique
                    series: [{
                        name: 'Ordinateur',
                        // Essayer d’abord avec des données fixes pour voir si le graphique s’affiche, par exemple,
                        //data : [2,10,3,3]
                        data: [<?php for ($i = 0; $i < count($tabEffectif); $i++) echo $tabEffectif[$i] . ","; ?>],
                        color: '#007096'
                    }]
                });
            </script>
        </section>
    </section>

    <!-- Création du SELECT dans la base données selon les champs remplis pour un rendu sous forme de tableau -->
    <section class="resultats">
        <?php
        // Si le formulaire a été soumis
        if (isset($_POST['recherche'])) {
            // Requête SQL initiale
            $requete = "SELECT * FROM ordinateur WHERE 1=1";

            // Ajouter des conditions à la requête selon les champs remplis
            if (!empty($_POST['marque'])) {
                $requete .= " AND marque = :marque";
            }
            if (!empty($_POST['game'])) {
                $requete .= " AND game = :game";
            }
            if (!empty($_POST['sys_exploit'])) {
                $requete .= " AND sys_exploit = :sys_exploit";
            }
            if (!empty($_POST['taille_ecran'])) {
                $requete .= " AND taille_ecran = :taille_ecran";
            }
            if (!empty($_POST['CPU_marque'])) {
                $requete .= " AND CPU_marque = :CPU_marque";
            }
            if (!empty($_POST['CPU_ref'])) {
                $requete .= " AND CPU_ref = :CPU_ref";
            }
            if (!empty($_POST['GPU'])) {
                $requete .= " AND GPU = :GPU";
            }
            if (!empty($_POST['RAM'])) {
                $requete .= " AND RAM = :RAM";
            }
            if (!empty($_POST['prix'])) {
                $requete .= " AND prix <= :prix";
            }

            // Création de la requête avec les valeurs du formulaire
            include("./../connexion.php");
            $stmt = $connexion->prepare($requete);

            // Lier les paramètres aux valeurs du formulaire
            if (!empty($_POST['marque'])) {
                $stmt->bindParam(':marque', $_POST['marque']);
            }
            if (!empty($_POST['game'])) {
                $stmt->bindParam(':game', $_POST['game']);
            }
            if (!empty($_POST['sys_exploit'])) {
                $stmt->bindParam(':sys_exploit', $_POST['sys_exploit']);
            }
            if (!empty($_POST['taille_ecran'])) {
                $stmt->bindParam(':taille_ecran', $_POST['taille_ecran']);
            }
            if (!empty($_POST['CPU_marque'])) {
                $stmt->bindParam(':CPU_marque', $_POST['CPU_marque']);
            }
            if (!empty($_POST['CPU_ref'])) {
                $stmt->bindParam(':CPU_ref', $_POST['CPU_ref']);
            }
            if (!empty($_POST['GPU'])) {
                $stmt->bindParam(':GPU', $_POST['GPU']);
            }
            if (!empty($_POST['RAM'])) {
                $stmt->bindParam(':RAM', $_POST['RAM']);
            }
            if (!empty($_POST['prix'])) {
                $stmt->bindParam(':prix', $_POST['prix']);
            }

            // Exécuter la requête
            $stmt->execute();
            $resultats = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Afficher les résultats
            if ($resultats) {
                echo "<h2>Résultats de la recherche</h2>";
                echo "<table border='1'>";
                echo "<tr><th>Marque</th><th>Game</th><th>Système</th><th>Taille d'écran</th><th>CPU Marque</th><th>CPU Ref</th><th>GPU</th><th>RAM</th><th>Autonomie</th><th>Prix</th></tr>";
                foreach ($resultats as $ordinateur) {
                    echo "<tr>";
                    echo "<td>" . $ordinateur['marque'] . "</td>";
                    echo "<td>" . $ordinateur['game'] . "</td>";
                    echo "<td>" . $ordinateur['sys_exploit'] . "</td>";
                    echo "<td>" . $ordinateur['taille_ecran'] . "</td>";
                    echo "<td>" . $ordinateur['CPU_marque'] . "</td>";
                    echo "<td>" . $ordinateur['CPU_ref'] . "</td>";
                    echo "<td>" . $ordinateur['GPU'] . "</td>";
                    echo "<td>" . $ordinateur['RAM'] . "</td>";
                    echo "<td>" . $ordinateur['autonomie'] . "</td>";
                    echo "<td>" . $ordinateur['prix'] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p>Aucun résultat trouvé</p>";
            }
        }
        ?>
    </section>

    <footer>
        Nous contacter :<br>
        Par mail : ordiginal@outlook.fr<br>
        Par téléphone : 07 55 62 17 23
    </footer>
    
</body>

</html>