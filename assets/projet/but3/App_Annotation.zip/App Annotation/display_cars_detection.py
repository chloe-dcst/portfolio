import base64
import io
import os
import json
import time
from zoneinfo import ZoneInfo
from datetime import datetime, timezone
from glob import glob
from typing import Optional, List, Dict, Any
from itertools import combinations

import numpy as np
import pandas as pd
from PIL import Image, ImageFile

# Compat : certains PNG interlaced / tronqués
ImageFile.LOAD_TRUNCATED_IMAGES = True

import dash
from dash import Dash, html, dcc, Input, Output, State, ctx, ClientsideFunction, ALL
import dash_bootstrap_components as dbc
from dash.exceptions import PreventUpdate
import plotly.graph_objects as go

# =========================
# 0) CONFIG & HELPERS
# =========================
APP_TITLE = "CarBox – Annotateur"
ALLOWED_USERS = {"admin", "qchabot", "lboudau","cdecoust"}

IMAGES_ROOT = os.path.join(".", "data", "cars_detection")

ANNOTATIONS_CSV = os.path.join(".", "data", "annotations.csv")
ANNOTATIONS_JSON = os.path.join(".", "data", "annotations.json")
HISTO_JSON = os.path.join(".", "data", "historique.json")
LOCK_DIR = os.path.join(".", "data")
IM_EXTS = {".jpg", ".jpeg", ".png"}

# UI tuning (responsive)
GRAPH_HEIGHT_CSS = "85vh"  # un poil plus haut
MAX_IMG_SIDE = 1600
THUMB_MAX_SIDE = 240

OUTSIDER_IOU_THRESHOLD = 0.5

# Ensure data directory + files
os.makedirs(os.path.dirname(ANNOTATIONS_CSV), exist_ok=True)
if not os.path.exists(ANNOTATIONS_CSV):
    cols = ["image_id","bbox_id","x","y","w","h","label","annotateur","created_at","updated_at","version"]
    pd.DataFrame(columns=cols).to_csv(ANNOTATIONS_CSV, index=False)
if not os.path.exists(ANNOTATIONS_JSON):
    with open(ANNOTATIONS_JSON, "w", encoding="utf-8") as f:
        json.dump([], f)
if not os.path.exists(HISTO_JSON):
    with open(HISTO_JSON, "w", encoding="utf-8") as f:
        json.dump([], f)


# ----- Lockfile simple (évite races I/O multi-users)
class FileLock:
    def __init__(self, name: str, timeout: float = 5.0, poll: float = 0.05):
        os.makedirs(LOCK_DIR, exist_ok=True)
        self.lock_path = os.path.join(LOCK_DIR, f"{name}.lock")
        self.timeout = timeout
        self.poll = poll
        self.acquired = False

    def __enter__(self):
        start = time.time()
        while True:
            try:
                fd = os.open(self.lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                with os.fdopen(fd, "w") as f:
                    f.write(str(os.getpid()))
                self.acquired = True
                return self
            except FileExistsError:
                if time.time() - start > self.timeout:
                    raise TimeoutError(f"Timeout acquiring lock {self.lock_path}")
                time.sleep(self.poll)

    def __exit__(self, exc_type, exc, tb):
        if self.acquired:
            try:
                os.remove(self.lock_path)
            except FileNotFoundError:
                pass
        self.acquired = False

# =========================
# 1) SERVER & APP
# =========================
from flask import Flask, session
server = Flask(__name__)
server.secret_key = os.environ.get("DASH_SECRET_KEY", "dev-secret-key")

external_stylesheets = [
    dbc.themes.BOOTSTRAP,
    "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap",
]

app = Dash(
    __name__,
    server=server,
    external_stylesheets=external_stylesheets,
    suppress_callback_exceptions=True,
    prevent_initial_callbacks="initial_duplicate",
    title=APP_TITLE,
)

# =========================
# 2) STYLES
# =========================
STYLE_VARS = {
    "bg_grad": "linear-gradient(135deg, #6366f1 0%, #4f46e5 40%, #06b6d4 100%)",
    "chip_bg": "#ffffffcc",
    "chip_fg": "#0f172a",
    "primary": "#4f46e5",
    "accent": "#06b6d4",
}
GLOBAL_CSS = {
    "fontFamily": "Inter, Roboto, system-ui, -apple-system, Segoe UI, Helvetica, Arial, sans-serif",
}
CARD_STYLE = {
    "borderRadius": "20px",
    "boxShadow": "0 12px 30px rgba(2,6,23,0.08)",
    "border": "0",
}

# Inject CSS (hover nav + qualité + tri + badges IoU)
app.index_string = app.index_string.replace(
    "</head>",
    """
<style>
.navbar .nav-link{padding:.5rem .9rem!important;position:relative;transition:color .2s ease,transform .2s ease}
.navbar .nav-link:hover{color:#e0f2fe!important;transform:translateY(-1px)}
.navbar .nav-link::after{content:"";position:absolute;left:12%;right:12%;bottom:-4px;height:2px;background:linear-gradient(90deg,#06b6d4,#4f46e5);transform:scaleX(0);transform-origin:center;transition:transform .2s ease;border-radius:2px}
.navbar .nav-link:hover::after{transform:scaleX(1)}
.qual-thumb-wrap{position:relative;width:180px;max-width:35vw;border-radius:10px;overflow:hidden}
.qual-thumb-wrap img{width:100%;height:auto;display:block}
.qual-overlay{position:absolute;inset:0;opacity:0;transition:opacity .15s ease}
.qual-thumb-wrap:hover .qual-overlay{opacity:1}
.qual-rect{position:absolute;border:2px solid rgba(15,23,42,.9);background:transparent;border-radius:3px}
.qual-label{position:absolute;transform:translateY(-100%);padding:2px 6px;background:rgba(255,255,255,.95);color:#0f172a;border:1px solid #cbd5e1;border-radius:6px;font-size:.72rem;line-height:1;white-space:nowrap;opacity:0;transition:opacity .15s ease}
.qual-thumb-wrap:hover .qual-label{opacity:1}
.qual-row{padding-top:8px;padding-bottom:8px}
.qual-row+.qual-row{border-top:1px solid #e5e7eb}
.qual-row:hover{background:#f8fafc}
.sortable{cursor:pointer;user-select:none}
.sort-active{font-weight:700;text-decoration:underline}
.badge-iou{padding:2px 6px;border-radius:8px;font-weight:700}
</style>
</head>
"""
)

# =========================
# 3) UTILITIES
# =========================
EXPECTED_COLS = ["image_id","bbox_id","x","y","w","h","label","annotateur","created_at","updated_at","version"]

def get_user_email():
    return session.get("user_email")

def list_images():
    if not IMAGES_ROOT:
        return []
    paths = [p for p in sorted(glob(os.path.join(IMAGES_ROOT, "*")))
             if os.path.splitext(p)[1].lower() in IM_EXTS]
    return [os.path.basename(p) for p in paths]

def _ensure_cols(df: pd.DataFrame) -> pd.DataFrame:
    for c in EXPECTED_COLS:
        if c not in df.columns: df[c] = pd.Series(dtype=object)
    return df[EXPECTED_COLS]

def load_json_annotations_df():
    try:
        if os.path.exists(ANNOTATIONS_JSON):
            with open(ANNOTATIONS_JSON, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, list):
                return _ensure_cols(pd.DataFrame(data))
    except Exception:
        pass
    return pd.DataFrame(columns=EXPECTED_COLS)

def save_annotations_both(df: pd.DataFrame):
    records = _ensure_cols(df).to_dict("records")
    with FileLock("annotations", timeout=5):
        with open(ANNOTATIONS_JSON, "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        _ensure_cols(df).to_csv(ANNOTATIONS_CSV, index=False)

def log_history(action: str, user: str, image_id: str,
                before: Optional[dict], after: Optional[dict]):
    entry = {
        "ts": datetime.now(ZoneInfo("Europe/Paris")).isoformat(),
        "action": action,
        "user": user,
        "image_id": image_id,
        "before": before,
        "after": after,
    }
    try:
        with FileLock("historique", timeout=5):
            existing = []
            if os.path.exists(HISTO_JSON):
                with open(HISTO_JSON, "r", encoding="utf-8") as f:
                    existing = json.load(f) or []
            existing.append(entry)
            with open(HISTO_JSON, "w", encoding="utf-8") as f:
                json.dump(existing, f, ensure_ascii=False, indent=2)
    except Exception:
        pass

def pil_to_base64(im: Image.Image) -> str:
    buff = io.BytesIO()
    im.save(buff, format="PNG")
    b64 = base64.b64encode(buff.getvalue()).decode("utf-8")
    return f"data:image/png;base64,{b64}"

def open_and_downscale(image_path: str, max_side=MAX_IMG_SIDE):
    im = Image.open(image_path).convert("RGB")
    w, h = im.size
    scale = min(1.0, max_side / max(w, h))
    if scale < 1.0:
        im = im.resize((int(w * scale), int(h * scale)), Image.LANCZOS)
    return im, scale

def get_downscaled_size(image_filename: str, max_side=MAX_IMG_SIDE):
    if not IMAGES_ROOT: return None
    p = os.path.join(IMAGES_ROOT, image_filename)
    if not os.path.exists(p): return None
    im = Image.open(p).convert("RGB")
    w, h = im.size
    scale = min(1.0, max_side / max(w, h))
    return int(w * scale), int(h * scale)

def figure_for_image(image_filename: str, uirev: str):
    if not IMAGES_ROOT or not image_filename:
        return go.Figure()
    path = os.path.join(IMAGES_ROOT, image_filename)
    if not os.path.exists(path):
        return go.Figure()

    im, _ = open_and_downscale(path)
    b64 = pil_to_base64(im)
    w, h = im.size

    fig = go.Figure()
    fig.add_layout_image(
        dict(source=b64, xref="x", yref="y", x=0, y=0, sizex=w, sizey=h, sizing="stretch", layer="below")
    )
    fig.update_xaxes(visible=False, range=[0, w])
    fig.update_yaxes(visible=False, range=[h, 0], scaleanchor="x", scaleratio=1, constrain="domain")
    fig.update_layout(
        dragmode="drawrect",
        margin=dict(l=0, r=0, t=0, b=0),
        newshape=dict(line_color=STYLE_VARS["accent"]),
        uirevision=uirev,
        autosize=True,
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )
    return fig

def shapes_from_rows(rows, line_color="#4f46e5", fill="rgba(79,70,229,0.18)"):
    shapes = []
    if not rows:
        return shapes
    for r in rows:
        try:
            x = float(r.get("x", 0)); y = float(r.get("y", 0))
            w = float(r.get("w", 0)); h = float(r.get("h", 0))
        except Exception:
            continue
        if w <= 0 or h <= 0:
            continue
        shapes.append({
            "type": "rect",
            "x0": x, "y0": y, "x1": x + w, "y1": y + h,
            "line": {"color": line_color, "width": 2},
            "fillcolor": fill,
            "editable": False,
        })
    return shapes

def rect_from_relayout(relayout):
    if not relayout:
        return None
    shapes = []
    if "shapes" in relayout:
        shapes = relayout["shapes"]
    else:
        keys = [k for k in relayout.keys() if k.startswith("shapes[") and k.endswith(".x0")]
        idxs = sorted({int(k.split("[")[1].split("]")[0]) for k in keys})
        for i in idxs:
            try:
                x0 = float(relayout.get(f"shapes[{i}].x0"))
                y0 = float(relayout.get(f"shapes[{i}].y0"))
                x1 = float(relayout.get(f"shapes[{i}].x1"))
                y1 = float(relayout.get(f"shapes[{i}].y1"))
                shapes.append({"x0": x0, "y0": y0, "x1": x1, "y1": y1})
            except Exception:
                continue
    if not shapes:
        return None
    s = shapes[-1]
    x0, y0, x1, y1 = float(s["x0"]), float(s["y0"]), float(s["x1"]), float(s["y1"])
    x, y = min(x0, x1), min(y0, y1)
    w, h = abs(x1 - x0), abs(y1 - y0)
    return {"x": x, "y": y, "w": w, "h": h}

def iou(boxA, boxB):
    xA = max(boxA["x"], boxB["x"])
    yA = max(boxA["y"], boxB["y"])
    xB = min(boxA["x"] + boxA["w"], boxB["x"] + boxB["w"])
    yB = min(boxA["y"] + boxA["h"], boxB["y"] + boxB["h"])
    inter_w = max(0, xB - xA)
    inter_h = max(0, yB - yA)
    interArea = inter_w * inter_h
    unionArea = boxA["w"] * boxA["h"] + boxB["w"] * boxB["h"] - interArea
    if unionArea <= 0:
        return 0.0
    return interArea / unionArea

def greedy_match_iou(boxesA, boxesB):
    pairs = []
    usedA, usedB = set(), set()
    candidates = []
    for i, a in enumerate(boxesA):
        for j, b in enumerate(boxesB):
            candidates.append((iou(a, b), i, j))
    candidates.sort(reverse=True, key=lambda t: t[0])
    for score, i, j in candidates:
        if i in usedA or j in usedB:
            continue
        usedA.add(i); usedB.add(j)
        pairs.append((score, i, j))
    return pairs

def external_annots_for_image(image_id: str, current_user: str) -> List[Dict[str, Any]]:
    df = load_json_annotations_df()
    if df.empty:
        return []
    df = df[df["image_id"] == image_id]
    if not current_user:
        others = df
    else:
        others = df[df["annotateur"] != current_user]
    if others.empty:
        return []
    others = (others.sort_values(["annotateur", "bbox_id", "version"])
                    .drop_duplicates(["annotateur", "bbox_id"], keep="last"))
    others = (others.sort_values(["annotateur", "version"])
                    .drop_duplicates(["annotateur"], keep="last"))
    return others[["x","y","w","h","label","annotateur"]].to_dict("records")

def load_image_thumb_b64(filename: str, max_side=THUMB_MAX_SIDE):
    if not IMAGES_ROOT:
        return None, None, None
    p = os.path.join(IMAGES_ROOT, filename)
    if not os.path.exists(p):
        return None, None, None
    im_thumb, _ = open_and_downscale(p, max_side=max_side)
    b64 = pil_to_base64(im_thumb)
    tw, th = im_thumb.size
    base_size = get_downscaled_size(filename, max_side=MAX_IMG_SIDE)
    return b64, tw, base_size

# =========================
# 4) COMPONENTS
# =========================
stores = html.Div([
    dcc.Store(id="store-user", storage_type="session"),
    dcc.Store(id="store-current-image"),
    dcc.Store(id="store-bboxes"),
    dcc.Store(id="store-last-relayout"),
    dcc.Store(id="store-pending-image"),
    dcc.Store(id="store-has-draft", data=False),
    dcc.Store(id="store-add-temp-disabled", data=False),
    dcc.Store(id="store-qual-sort", data={"col":"image","asc":True}),
])

nav = dbc.Navbar(
    dbc.Container([
        dbc.NavbarBrand(APP_TITLE, className="text-white fw-bold me-4"),
        html.Div(
            [
                dcc.Link("Annoter", href="/annotate", className="nav-link text-white fw-semibold me-4"),
                dcc.Link("Statistiques", href="/stats", className="nav-link text-white fw-semibold me-4"),
                dcc.Link("Contrôle qualité", href="/qualite", className="nav-link text-white fw-semibold me-4"),
                dcc.Link("Historique", href="/historique", className="nav-link text-white fw-semibold"),
            ],
            className="d-flex align-items-center",
            style={"gap": "1rem"}
        ),
        html.Div(id="user-pill", className="ms-auto d-flex align-items-center"),
    ]),
    style={"background": STYLE_VARS["bg_grad"], "borderRadius": "0 0 20px 20px"},
    dark=True,
)

# Login Page
login_page = html.Div(
    [
        dcc.Location(id="router-location"),
        stores,
        html.Div(
            dbc.Card(
                dbc.CardBody(
                    [
                        html.H2("Se connecter", className="mb-4 fw-bold"),
                        dbc.Input(id="login-username", placeholder="Nom d'utilisateur", type="text", className="mb-2"),
                        dbc.Input(id="login-password", placeholder="Mot de passe (1234)", type="password", className="mb-3"),
                        dbc.Button("Se connecter", id="btn-login", color="primary", className="w-100 mb-2", n_clicks=0,
                                   style={"background": STYLE_VARS["primary"], "border": "none"}),
                        dbc.Alert(id="login-alert", color="danger", is_open=False),
                    ]
                ),
                style={"maxWidth": 420, **CARD_STYLE}
            ),
            className="d-flex justify-content-center align-items-center vh-100",
            style={"background": STYLE_VARS["bg_grad"], "padding": "2rem"},
        ),
    ],
    style=GLOBAL_CSS,
)

# Annotate Page
image_controls = dbc.Card(
    dbc.CardBody([
        dbc.Row([
            dbc.Col([
                html.Label("Image"),
                dcc.Dropdown(id="image-select", options=[], placeholder="Choisir une image"),
            ], md=12)
        ], className="mb-3"),
        dbc.Row([
            dbc.Col(dbc.Button("⟵ Précédent", id="btn-prev", color="primary", className="w-100 fw-semibold shadow-sm"), md=6),
            dbc.Col(dbc.Button("Suivant ⟶", id="btn-next", color="primary", className="w-100 fw-semibold shadow-sm"), md=6),
        ], className="mb-3"),
        dbc.Row([
            dbc.Col([
                html.Label("Étiquette (ex: voiture)"),
                dbc.Input(id="input-label", value="voiture", type="text"),
            ], md=12),
        ], className="mb-3"),
        dbc.Row([
            dbc.Col(
                dbc.Checklist(
                    id="toggle-others",
                    options=[{"label": "Afficher les annotations des autres", "value": "show"}],
                    value=["show"],
                    switch=True,
                ),
                md=12
            ),
        ], className="mb-2"),
        dbc.Row([
            dbc.Col(dbc.Button("Ajouter", id="btn-add", color="success", className="w-100", disabled=True), md=6),
            dbc.Col(dbc.Button("Supprimer", id="btn-delete", color="danger", className="w-100"), md=6),
        ], className="mb-3"),

        dcc.Interval(id="int-debounce-add", interval=300, disabled=True, n_intervals=0),

        dbc.Toast(
            id="toast-save",
            header="Sauvegarde",
            is_open=False,
            dismissable=True,
            duration=1800,
            color="success",
            icon="check",
            children="Annotation enregistrée",
            style={"position": "fixed", "top": 20, "right": 20, "zIndex": 2000},
        ),
        dbc.Toast(
            id="toast-error",
            header="Erreur",
            is_open=False,
            dismissable=True,
            duration=2800,
            color="danger",
            icon="exclamation-triangle"),
        # Astuce retirée à la demande
    ]),
    style={**CARD_STYLE}
)

image_area = dbc.Card(
    dbc.CardBody([
        dcc.Loading(
            dcc.Graph(
                id="graph-image",
                config={"modeBarButtonsToAdd": ["drawrect", "eraseshape"], "doubleClick": "reset"},
                style={"height": GRAPH_HEIGHT_CSS, "width": "100%"}
            ),
            type="dot"
        ),
        dcc.Store(id="store-image-scale"),
    ]),
    style={**CARD_STYLE}
)

annotate_page = html.Div([
    dcc.Location(id="router-location-2"),
    stores,
    nav,
    dbc.Container([
        dbc.Row([
            dbc.Col(image_area, md=8, className="mb-3"),
            dbc.Col(image_controls, md=4, className="mb-3"),
        ], className="mt-3"),
    ], fluid=True),
], style=GLOBAL_CSS)

# Stats Page
stats_filters = dbc.Card(
    dbc.CardBody([
        dbc.Row([
            dbc.Col([
                html.Label("Annotateur"),
                dcc.Dropdown(id="stats-user", options=[], value="__ALL__", multi=False),
            ], md=4),
            dbc.Col([
                html.Label("Dates"),
                dcc.DatePickerRange(id="stats-dates"),
            ], md=8)
        ])
    ]), style={**CARD_STYLE}
)
stats_kpis = dbc.Row([
    dbc.Col(dbc.Card(dbc.CardBody([html.Div("Images totales", className="text-muted"), html.H3(id="kpi-images-total") ]), style=CARD_STYLE), md=3),
    dbc.Col(dbc.Card(dbc.CardBody([html.Div("Images annotées", className="text-muted"), html.H3(id="kpi-images-annot") ]), style=CARD_STYLE), md=3),
    dbc.Col(dbc.Card(dbc.CardBody([html.Div("Total d’annotations", className="text-muted"), html.H3(id="kpi-bboxes") ]), style=CARD_STYLE), md=3),
    dbc.Col(dbc.Card(dbc.CardBody([html.Div("Annotateurs", className="text-muted"), html.H3(id="kpi-users") ]), style=CARD_STYLE), md=3),
])
stats_charts = dbc.Row([
    dbc.Col(dbc.Card(dbc.CardBody([dcc.Graph(id="chart-by-user")]), style=CARD_STYLE), md=4),
    dbc.Col(dbc.Card(dbc.CardBody([dcc.Graph(id="chart-by-image")]), style=CARD_STYLE), md=4),
    dbc.Col(dbc.Card(dbc.CardBody([dcc.Graph(id="chart-by-day")]), style=CARD_STYLE), md=4),
])
stats_page = html.Div([
    dcc.Location(id="router-location-3"),
    stores,
    nav,
    dbc.Container([
        html.Div(stats_filters, className="mt-3 mb-3"),
        stats_kpis,
        html.Div(stats_charts, className="mt-3 mb-4"),
    ], fluid=True)
], style=GLOBAL_CSS)

# =========================
# Historique Page
# =========================
def _normalize_log_hist(raw: Dict[str, Any]):
    action = str(raw.get("action", "AUTRES") or "AUTRES").upper()
    user = str(raw.get("user", "Inconnu") or "Inconnu")
    image = str(raw.get("image", raw.get("image_id", "N/A")) or "N/A")
    details = raw.get("details")
    if details is None:
        b = raw.get("before"); a = raw.get("after")
        try:
            b_s = json.dumps(b, ensure_ascii=False) if b is not None else ""
            a_s = json.dumps(a, ensure_ascii=False) if a is not None else ""
        except Exception:
            b_s = str(b) if b is not None else ""
            a_s = str(a) if a is not None else ""
        if b_s or a_s:
            details = (f"Avant: {b_s[:120]}{'…' if len(b_s) > 120 else ''}  →  "
                       f"Après: {a_s[:120]}{'…' if len(a_s) > 120 else ''}").strip()
        else:
            details = "N/A"
    details = str(details)
    ts = raw.get("timestamp") or raw.get("time") or raw.get("ts")
    if ts is None:
        timestamp = "N/A"; dt_for_sort = None
    else:
        timestamp = str(ts)
        ts_norm = timestamp.replace("Z", "+00:00") if isinstance(timestamp, str) else timestamp
        try: dt_for_sort = datetime.fromisoformat(ts_norm)
        except Exception: dt_for_sort = None
    return {"action": action, "user": user, "image": image, "details": details,
            "timestamp": timestamp, "_dt": dt_for_sort}

def _safe_read_history(path: str) -> Optional[List[Dict[str, Any]]]:
    if not os.path.exists(path): return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return []
    if isinstance(data, dict) and isinstance(data.get("logs"), list):
        logs_raw = data["logs"]
    elif isinstance(data, list):
        logs_raw = data
    else:
        return []
    logs = [_normalize_log_hist(item if isinstance(item, dict) else {}) for item in logs_raw]
    # Ignorer CHANGEMENT_IMAGE à l’affichage
    logs = [it for it in logs if it["action"] != "CHANGEMENT_IMAGE"]
    def _sort_key(it):
        if it["_dt"] is not None: return (0, it["_dt"])
        return (1, str(it["timestamp"]))
    logs.sort(key=_sort_key, reverse=True)
    return logs[:100]

ACTION_STYLE = {
    "CONNEXION":        {"emoji": "🔐", "color": "#3b82f6"},
    "EFFACEMENT":       {"emoji": "🗑️", "color": "#ef4444"},
    "ANNOTATION":       {"emoji": "✏️", "color": "#10b981"},
}
DEFAULT_STYLE = {"emoji": "❓", "color": "#666"}

historique_page = html.Div([
    dcc.Location(id="router-location-5"),
    stores,
    nav,
    dbc.Container([
        dcc.Store(id="store-histo-filter", data="__ALL__"),
        html.Br(), html.Br(),
        html.H1("📋 Historique des actions", style={'textAlign': 'center', 'color': '#2196F3'}),
        html.Div(
            id='historisation-log',
            style={
                'maxHeight': '70vh',
                'overflowY': 'auto',
                'border': '2px solid #ddd',
                'padding': '20px',
                'backgroundColor': '#f5f7fb',
                'borderRadius': '12px',
                'margin': '20px 0'
            }
        )
    ], fluid=True)
], style=GLOBAL_CSS)

# =========================
# Contrôle Qualité (tri + couleurs IoU + OUTSIDER + overlay on hover)
# =========================
def _hash_color(name: str) -> str:
    """Génère une couleur stable (hex) à partir d'un nom d'annotateur."""
    h = abs(hash(name)) % 360
    return f"hsl({h}, 70%, 45%)"
# =========================
# Contrôle Qualité (avec OUTSIDER + paires min/max nommées)
# =========================
# =========================
# Contrôle Qualité (OUTSIDER + paires nommées + "—" si un seul annotateur)
# =========================
def build_quality_rows(sort_state: Dict[str, Any]):
    df = load_json_annotations_df()
    if df.empty:
        return html.Div("Aucune annotation pour le moment.", className="text-muted")

    # dernière bbox par (image_id, annotateur)
    df_last = (df.sort_values(["image_id", "annotateur", "bbox_id", "version"])
                 .drop_duplicates(["image_id", "annotateur"], keep="last"))

    rows_meta = []
    for image_id, df_img in df_last.groupby("image_id"):
        users = df_img["annotateur"].dropna().tolist()
        n_annot = len(users)
        has_pairs = n_annot >= 2

        # boxes par user
        boxes = {
            r["annotateur"]: {
                "x": float(r["x"]), "y": float(r["y"]),
                "w": float(r["w"]), "h": float(r["h"])
            }
            for _, r in df_img.iterrows()
        }

        # Chevauchement (IoU) min/max + consensus (moyen) + paires (noms)
        min_pair = None
        max_pair = None
        if has_pairs:
            pair_ious = []
            for a, b in combinations(users, 2):
                s = iou(boxes[a], boxes[b])
                pair_ious.append((s, a, b))
            if pair_ious:
                min_iou, a_min, b_min = min(pair_ious, key=lambda t: t[0])
                max_iou, a_max, b_max = max(pair_ious, key=lambda t: t[0])
                min_pair = (a_min, b_min)
                max_pair = (a_max, b_max)
                mean_iou = float(np.mean([t[0] for t in pair_ious]))
            else:
                min_iou = max_iou = mean_iou = 0.0
                has_pairs = False  # sécurité
        else:
            # Valeurs neutres pour le tri; l'affichage mettra "—"
            min_iou = max_iou = mean_iou = 0.0

        # OUTSIDER : moyenne d’IoU la plus faible
        outsider_user = "aucun"
        if has_pairs:
            avg_by_user = {}
            for u in users:
                others = [v for v in users if v != u]
                scores = [iou(boxes[u], boxes[v]) for v in others] if others else []
                avg_by_user[u] = float(np.mean(scores)) if scores else 0.0
            u_min, v_min = min(avg_by_user.items(), key=lambda kv: kv[1])
            if v_min <= OUTSIDER_IOU_THRESHOLD:
                outsider_user = u_min

        # Rects overlay pour la vignette
        rects_raw = []
        for _, r in df_img.iterrows():
            rects_raw.append({
                "x": float(r["x"]), "y": float(r["y"]),
                "w": float(r["w"]), "h": float(r["h"]),
                "annotateur": str(r["annotateur"])
            })

        rows_meta.append({
            "image": image_id,
            "users": ", ".join(users) or "—",
            "min_iou": float(min_iou),
            "max_iou": float(max_iou),
            "mean_iou": float(mean_iou),
            "min_pair": min_pair,
            "max_pair": max_pair,
            "outsider": outsider_user,
            "has_pairs": has_pairs,
            "rects": rects_raw,
            "thumb": load_image_thumb_b64(image_id)
        })

    # tri courant
    col = (sort_state or {}).get("col", "image")
    asc = bool((sort_state or {}).get("asc", True))
    rows_meta.sort(
        key=lambda r: (r[col] if col in {"image", "users", "outsider"} else float(r[col])),
        reverse=not asc
    )

    def th(label, colname):
        active = " sort-active" if col == colname else ""
        return html.Span(label, id={"type": "qual-sort", "col": colname},
                         className="sortable" + active)

    header = dbc.Row([
        dbc.Col(th("Image", "image"), md=2),
        dbc.Col(th("Annotateurs", "users"), md=3),
        dbc.Col(th("IoU moyen", "mean_iou"), md=2),
        dbc.Col(th("IoU min (paire)", "min_iou"), md=2),
        dbc.Col(th("IoU max (paire)", "max_iou"), md=2),
        dbc.Col(th("Outsider", "outsider"), md=1),
    ], className="py-1", style={"borderBottom": "1px solid #e5e7eb"})

    def iou_badge(value: float, has_pair: bool):
        # Affichage "—" si un seul annotateur
        if not has_pair:
            return html.Span("—", className="badge-iou",
                             style={"backgroundColor": "#e5e7eb", "color": "#64748b"})
        if value < 0.3:
            bg = "rgba(239,68,68,.15)"; fg = "#ef4444"
        elif value < 0.5:
            bg = "rgba(245,158,11,.18)"; fg = "#f59e0b"
        else:
            bg = "rgba(16,185,129,.18)"; fg = "#10b981"
        return html.Span(f"{value:.2f}", className="badge-iou",
                         style={"backgroundColor": bg, "color": fg})

    def iou_cell(value: float, pair, has_pair: bool):
        if not has_pair:
            # Pas de paire => tiret et paire vide
            return html.Span([
                iou_badge(value, has_pair=False),
                html.Span(" (—)", style={"marginLeft": "6px", "color": "#64748b"})
            ])
        # Avec paires nommées
        pair_txt = f" ({pair[0]}, {pair[1]})" if pair and len(pair) == 2 else " (—)"
        return html.Span([
            iou_badge(value, has_pair=True),
            html.Span(pair_txt, style={"marginLeft": "6px", "color": "#64748b"})
        ])

    rows = [header]
    for meta in rows_meta:
        image_id = meta["image"]
        users = meta["users"]
        has_pairs = bool(meta["has_pairs"])
        min_iou = meta["min_iou"]; max_iou = meta["max_iou"]; mean_iou = meta["mean_iou"]
        min_pair = meta["min_pair"]; max_pair = meta["max_pair"]
        outsider = meta["outsider"]
        thumb_b64, tw, base_size = meta["thumb"]
        img_cell = _quality_image_cell(image_id, thumb_b64, tw, base_size, rects=meta["rects"])

        rows.append(dbc.Row([
            dbc.Col(img_cell, md=2, className="py-1"),
            dbc.Col(users, md=3, className="py-1"),
            dbc.Col(iou_badge(mean_iou, has_pairs), md=2, className="py-1"),
            dbc.Col(iou_cell(min_iou, min_pair, has_pairs), md=2, className="py-1"),
            dbc.Col(iou_cell(max_iou, max_pair, has_pairs), md=2, className="py-1"),
            dbc.Col(
                html.Span(
                    outsider,
                    style={"color": "#ef4444"} if (outsider != "aucun" and has_pairs) else {"color": "#64748b"}
                ),
                md=1, className="py-1"
            ),
        ], className="qual-row"))

    return html.Div(rows, className="mt-2 mb-3")


def _quality_image_cell(image_id, thumb_b64, thumb_w, base_size, rects):
    if not thumb_b64:
        return html.Div("Image manquante", className="text-muted")
    overlay_children = []
    if base_size and rects:
        base_w, base_h = base_size
        if base_w > 0 and base_h > 0:
            s = 180.0 / float(base_w)
            for r in rects:
                left = r["x"] * s
                top = r["y"] * s
                w = r["w"] * s
                h = r["h"] * s
                color = _hash_color(r["annotateur"])
                overlay_children.append(html.Div([
                    html.Div(
                        className="qual-rect",
                        title=r["annotateur"],
                        style={
                            "left": f"{left}px", "top": f"{top}px",
                            "width": f"{w}px", "height": f"{h}px",
                            "borderColor": color,
                            "background": "transparent"
                        }
                    ),
                    html.Span(r["annotateur"], className="qual-label", style={
                        "left": f"{left}px",
                        "top": f"{top}px",
                        "borderColor": color
                    })
                ]))
    return html.Div([
        html.Div([
            html.Img(
                id={"type":"qual-img","image_id": image_id},
                src=thumb_b64,
                style={"cursor":"pointer"}
            ),
            html.Div(overlay_children, className="qual-overlay")
        ], className="qual-thumb-wrap", style={"width": "180px"})
    ])

qual_page = html.Div([
    dcc.Location(id="router-location-4"),
    stores,
    nav,
    dbc.Container([
        html.H2("Contrôle qualité", className="mt-3"),
        dbc.Alert(
            [
                html.Strong("À propos du chevauchement (IoU – Intersection over Union) : "),
                html.Br(),
                "Le chevauchement, aussi appelé IoU (Intersection over Union), est une métrique qui permet de mesurer à quel point deux boîtes englobantes se recouvrent l’une l’autre. ",
                html.Br(),
                "Techniquement, l’IoU correspond au rapport entre l’aire de l’intersection des deux boîtes et l’aire de leur union, c’est-à-dire : ",
                "aire(intersection) / aire(union). ",
                html.Br(),
                "La valeur obtenue est toujours comprise entre 0 et 1. ",
                html.Br(),
                "Un IoU proche de 1 signifie que les deux annotations sont quasiment identiques, ce qui reflète un accord fort entre annotateurs. ",
                html.Br(),
                "À l’inverse, un IoU faible (proche de 0) indique que les boîtes se recouvrent peu ou pas du tout, ce qui peut révéler une erreur d’annotation ou une ambiguïté dans l’image. ",
                html.Br(),
                "Par exemple : deux boîtes qui se chevauchent presque entièrement donneront un IoU d’environ 0.85, alors que deux boîtes éloignées l’une de l’autre donneront un IoU proche de 0.10. "
            ],
            color="info",
            className="mb-2",
            style={"fontSize": ".92rem"}
        ),
        html.Div(id="qual-table", className="mt-2 mb-4"),
    ], fluid=True)
], style=GLOBAL_CSS)

# Validation layout
app.validation_layout = html.Div([
    login_page, annotate_page, stats_page, qual_page, historique_page
])

# =========================
# 5) APP LAYOUT & ROUTING
# =========================
app.layout = html.Div([
    dcc.Location(id="router"),
    stores,
    html.Div(id="page-content")
])

@app.callback(Output("page-content", "children"), Input("router", "pathname"))
def render_page(pathname):
    if pathname == "/login" or pathname is None:
        return login_page
    if pathname == "/annotate":
        if not get_user_email():
            return dcc.Location(id="router-redirect", href="/login")
        return annotate_page
    if pathname == "/stats":
        if not get_user_email():
            return dcc.Location(id="router-redirect", href="/login")
        return stats_page
    if pathname == "/qualite":
        if not get_user_email():
            return dcc.Location(id="router-redirect", href="/login")
        return qual_page
    if pathname == "/historique":
        if not get_user_email():
            return dcc.Location(id="router-redirect", href="/login")
        return historique_page
    return dcc.Location(id="router-redirect", href="/login")

# =========================
# 6) AUTH
# =========================
@app.callback(
    Output("login-alert", "is_open"),
    Output("login-alert", "children"),
    Output("store-user", "data"),
    Output("router", "href"),
    Input("btn-login", "n_clicks"),
    State("login-username", "value"),
    State("login-password", "value"),
    prevent_initial_call=True,
)
def do_login(nc, username, password):
    if not nc:
        raise PreventUpdate
    if not username:
        return True, "Merci d'indiquer un identifiant.", dash.no_update, dash.no_update
    if not password:
        return True, "Merci d'indiquer le mot de passe.", dash.no_update, dash.no_update
    user = str(username).strip()
    if (user in ALLOWED_USERS or user.endswith("@local")) and str(password) == "1234":
        session["user_email"] = user
        log_history("CONNEXION", user, "-", None, {"user": user})
        return False, "", {"email": user}, "/annotate"
    return True, "Identifiants invalides (utilisateur autorisé + mot de passe 1234)", dash.no_update, dash.no_update

@app.callback(Output("user-pill", "children"), Input("router", "pathname"))
def show_user(_):
    user = get_user_email()
    if not user:
        return dbc.Button("Se connecter", href="/login", color="light")
    return html.Div([
        html.Span(user, className="px-3 py-2 rounded-pill",
                  style={"background": STYLE_VARS["chip_bg"], "color": STYLE_VARS["chip_fg"], "fontWeight": 600}),
        dbc.Button("Se déconnecter", id="btn-logout", size="sm", color="light", className="ms-2",
                   style={"background": "#ffffff33", "border": "0", "color": "white", "backdropFilter": "blur(2px)"}),
    ])

@app.callback(
    Output("router", "href", allow_duplicate=True),
    Input("btn-logout", "n_clicks"),
    prevent_initial_call=True
)
def logout(n):
    if not n:
        raise PreventUpdate
    session.pop("user_email", None)
    return "/login"

# =========================
# 7) ANNOTATION (écritures UNIQUEMENT via Ajouter/Supprimer)
# =========================
@app.callback(
    Output("image-select", "options"),
    Output("image-select", "value"),
    Input("router", "pathname"),
    State("store-pending-image", "data"),
)
def populate_images(pathname, pending):
    if pathname != "/annotate":
        raise PreventUpdate
    imgs = list_images()
    value = imgs[0] if imgs else None
    if pending and pending.get("image") in imgs:
        value = pending.get("image")
    return [{"label": i, "value": i} for i in imgs], value

@app.callback(Output("store-pending-image", "data"), Input("image-select", "value"))
def clear_pending(_):
    return None

def _rev_key(image_id, my_rows):
    ver = 0
    if my_rows and isinstance(my_rows, list) and len(my_rows) > 0:
        try:
            ver = int(my_rows[0].get("version", 0))
        except Exception:
            ver = 0
    return f"{image_id or 'noimg'}__v{ver}"

@app.callback(
    Output("store-current-image", "data"),
    Input("image-select", "value"),
    State("router", "pathname"),
)
def set_current_image(img, pathname):
    if pathname != "/annotate":
        raise PreventUpdate
    return {"image": img}

@app.callback(
    Output("graph-image", "figure", allow_duplicate=True),
    Output("store-image-scale", "data"),
    Input("store-current-image", "data"),
    Input("store-bboxes", "data"),
    Input("toggle-others", "value"),
    State("router", "pathname"),
)
def update_figure(current, my_rows, toggle_others, pathname):
    if pathname != "/annotate":
        raise PreventUpdate

    img = (current or {}).get("image")
    uirev = _rev_key(img, my_rows)
    fig = figure_for_image(img, uirev)

    # Mes formes (affichage seulement)
    shapes_me = shapes_from_rows(
        my_rows or [],
        line_color=STYLE_VARS["primary"],
        fill="rgba(79,70,229,0.25)"
    )

    # Autres formes (25% opacité) — option d’affichage
    show_others = isinstance(toggle_others, list) and ("show" in toggle_others)
    annotations = []
    shapes_others = []
    if show_others:
        current_user = get_user_email() or ""
        others = external_annots_for_image(img, current_user)
        shapes_others = shapes_from_rows(
            others,
            line_color="#64748b",
            fill="rgba(100,116,139,0.25)"
        )
        # Étiquettes (autres)
        def label_box(x, y, text, border="#475569", font_color="#111827"):
            return dict(
                x=float(x) + 1, y=float(y) - 2, xref="x", yref="y", text=str(text),
                showarrow=False, xanchor="left", yanchor="bottom", align="left",
                bgcolor="rgba(255,255,255,0.95)", bordercolor=border, borderwidth=1, borderpad=3,
                font=dict(size=12, color=font_color), opacity=1
            )
        for r in others:
            try:
                x = float(r.get("x", 0)); y = float(r.get("y", 0))
                who = str(r.get("annotateur", "autre"))
                annotations.append(label_box(x, y, who, border="#475569", font_color="#334155"))
            except Exception:
                continue

    fig.update_layout(shapes=shapes_others + shapes_me, annotations=annotations)

    # scale
    scale = None
    try:
        if img and IMAGES_ROOT:
            path = os.path.join(IMAGES_ROOT, img)
            if os.path.exists(path):
                _, sc = open_and_downscale(path)
                scale = sc
    except Exception:
        pass

    return fig, {"scale": scale}

@app.callback(Output("store-last-relayout", "data"), Input("graph-image", "relayoutData"))
def capture_relayout(relayout):
    return relayout

# ---- Version serveur de la logique clientside (évite erreurs JS)
@app.callback(
    Output("graph-image", "figure", allow_duplicate=True),
    Input("graph-image", "relayoutData"),
    State("graph-image", "figure"),
    prevent_initial_call=True,
)
def draft_zoom_manager_server(relayout_data, figure):
    if not figure or "layout" not in figure:
        raise PreventUpdate
    layout = figure.get("layout", {})
    shapes = list(layout.get("shapes", []))

    # Séparer formes fixes et drafts
    fixed = [s for s in shapes if s and s.get("editable") is False]
    drafts = [s for s in shapes if not s or s.get("editable") is not False]

    mutated = False

    # 1) Conserver un seul draft (le dernier) et forcer pan
    if len(drafts) > 0:
        last_draft = drafts[-1]
        new_shapes = fixed + [last_draft]
        if json.dumps(new_shapes, sort_keys=True) != json.dumps(shapes, sort_keys=True):
            layout["shapes"] = new_shapes
            mutated = True
        if layout.get("dragmode") != "pan":
            layout["dragmode"] = "pan"
            mutated = True

    # 2) Après zoom/pan, s'il n'y a plus de draft, remettre drawrect
    looks_like_zoom = bool(relayout_data) and any(
        isinstance(k, str) and (k.startswith("xaxis.") or k.startswith("yaxis.") or ".range[" in k)
        for k in relayout_data.keys()
    )
    if len(drafts) == 0 and looks_like_zoom:
        if layout.get("dragmode") != "drawrect":
            layout["dragmode"] = "drawrect"
            mutated = True

    if mutated:
        figure["layout"] = layout
        return figure
    raise PreventUpdate


@app.callback(
    Output("store-has-draft", "data"),
    Input("graph-image", "relayoutData"),
    State("graph-image", "figure"),
    prevent_initial_call=True,
)
def update_has_draft_server(_relayout_data, figure):
    if not figure or "layout" not in figure:
        return False
    shapes = figure.get("layout", {}).get("shapes", []) or []
    drafts = [s for s in shapes if not s or s.get("editable") is not False]
    return len(drafts) > 0

# Ajouter/Supprimer : seules actions qui PERSISTENT
@app.callback(
    Output("store-bboxes", "data"),
    Output("toast-save", "is_open"),
    Output("toast-error", "is_open"),
    Output("toast-error", "children"),
    Input("btn-add", "n_clicks"),
    Input("btn-delete", "n_clicks"),
    Input("image-select", "value"),
    State("store-bboxes", "data"),
    State("store-last-relayout", "data"),
    State("input-label", "value"),
    State("router", "pathname"),
    prevent_initial_call=True,
)
def bboxes_ops(n_add, n_del, image_value, rows, relayout, label, pathname):
    if pathname != "/annotate":
        raise PreventUpdate
    rows = rows or []
    trig = ctx.triggered_id
    email = get_user_email() or ""
    if not image_value or not email:
        return rows, False, True, "Utilisateur ou image manquant."

    def latest_for_me():
        dfj = load_json_annotations_df()
        if dfj.empty:
            return None
        df_sel = dfj[(dfj["image_id"] == image_value) & (dfj["annotateur"] == email)]
        if df_sel.empty:
            return None
        rec = df_sel.sort_values(["bbox_id","version"]).tail(1).iloc[0].to_dict()
        return {k: rec[k] for k in ["bbox_id","x","y","w","h","label","version","created_at","updated_at"]}

    def persist(current_rows):
        df_json = load_json_annotations_df()
        now = datetime.now(timezone.utc).isoformat()
        if not df_json.empty:
            keep = ~((df_json["image_id"] == image_value) & (df_json["annotateur"] == email))
            df_json = df_json[keep]
        new_rows = []
        if current_rows:
            r = current_rows[0].copy()
            df_all = load_json_annotations_df()
            mask = (df_all["image_id"] == image_value) & (df_all["annotateur"] == email)
            if not df_all.empty and mask.any():
                prev_v = int(df_all.loc[mask, "version"].max())
                r["version"] = prev_v + 1
                created_at = df_all.loc[mask, "created_at"].iloc[0]
            else:
                created_at = now
                r["version"] = int(r.get("version", 0) or 1)
            r["image_id"] = image_value
            r["annotateur"] = email
            r["created_at"] = created_at
            r["updated_at"] = now
            new_rows.append(r)
        df_final = pd.concat([df_json, pd.DataFrame(new_rows)], ignore_index=True)
        save_annotations_both(df_final)

    if trig == "btn-add":
        current_persisted = latest_for_me()
        if current_persisted is not None:
            return [current_persisted], False, True, "Vous avez déjà une annotation pour cette image. Supprimez-la avant d’en ajouter une nouvelle."

        rect = rect_from_relayout(relayout)
        if rect is None:
            return rows, False, True, "Aucun rectangle tracé."
        if rect["w"] <= 0 or rect["h"] <= 0:
            return rows, False, True, "Rectangle invalide (largeur/hauteur nulles)."

        rect["label"] = label or "voiture"
        rect["bbox_id"] = 1
        rect["version"] = 1
        rows = [rect]
        log_history("ANNOTATION", email, image_value, None, rect)
        persist(rows)
        return rows, True, False, dash.no_update

    elif trig == "btn-delete":
        current = latest_for_me()
        if not current and not rows:
            return rows, False, True, "Aucune annotation à supprimer."
        before = current if current else rows[0]
        rows = []
        log_history("EFFACEMENT", email, image_value, before, None)
        persist(rows)
        return rows, True, False, dash.no_update

    elif trig == "image-select":
        current = latest_for_me()
        rows = [current] if current else []
        return rows, False, False, dash.no_update

    return rows, False, False, dash.no_update

# Débounce “Ajouter”
@app.callback(
    Output("store-add-temp-disabled", "data"),
    Output("int-debounce-add", "disabled"),
    Output("int-debounce-add", "n_intervals"),
    Input("btn-add", "n_clicks"),
    Input("int-debounce-add", "n_intervals"),
    State("int-debounce-add", "disabled"),
    prevent_initial_call=True,
)
def debounce_add(n_clicks_add, n_intervals, interval_disabled):
    trig = ctx.triggered_id
    if trig == "btn-add":
        if not n_clicks_add:
            raise PreventUpdate
        return True, False, 0
    if trig == "int-debounce-add":
        if interval_disabled:
            raise PreventUpdate
        if (n_intervals or 0) >= 1:
            return False, True, n_intervals
    raise PreventUpdate

# Activer/désactiver btn-add : nécessite un draft ET pas de debounce
@app.callback(
    Output("btn-add", "disabled"),
    Input("store-has-draft", "data"),
    Input("store-add-temp-disabled", "data"),
)
def compute_add_disabled(has_draft, temp_disabled):
    return (not bool(has_draft)) or bool(temp_disabled)

# =========================
# 8) STATS
# =========================
@app.callback(
    Output("stats-user", "options"),
    Output("stats-user", "value"),
    Output("stats-dates", "start_date"),
    Output("stats-dates", "end_date"),
    Input("router", "pathname"),
)
def init_stats_filters(pathname):
    if pathname != "/stats":
        raise PreventUpdate
    df = load_json_annotations_df()
    df = _ensure_cols(df)
    users = sorted([u for u in df["annotateur"].dropna().unique().tolist() if u])

    options = [{"label": "Tous", "value": "__ALL__"}] + [{"label": u, "value": u} for u in users]

    dates = pd.to_datetime(pd.concat([df["created_at"], df["updated_at"]], ignore_index=True), errors="coerce")
    start = dates.min(); end = dates.max()
    return (
        options,
        "__ALL__",
        start.date().isoformat() if pd.notnull(start) else None,
        end.date().isoformat() if pd.notnull(end) else None
    )

@app.callback(
    Output("kpi-images-total", "children"),
    Output("kpi-images-annot", "children"),
    Output("kpi-bboxes", "children"),
    Output("kpi-users", "children"),
    Output("chart-by-user", "figure"),
    Output("chart-by-image", "figure"),
    Output("chart-by-day", "figure"),
    Input("stats-user", "value"),
    Input("stats-dates", "start_date"),
    Input("stats-dates", "end_date"),
    Input("router", "pathname"),
)
def update_stats(user, start_date, end_date, pathname):
    if pathname != "/stats":
        raise PreventUpdate
    imgs = list_images()
    total_images = len(imgs)
    df = _ensure_cols(load_json_annotations_df())

    if user and user != "__ALL__":
        df = df[df["annotateur"] == user]
    if start_date:
        df = df[df["created_at"] >= start_date]
    if end_date:
        df = df[df["created_at"] <= (pd.to_datetime(end_date) + pd.Timedelta(days=1)).isoformat()]

    images_annot = df["image_id"].nunique()
    total_bboxes = len(df)
    nb_users = df["annotateur"].nunique()

    by_user = df.groupby("annotateur").size().reset_index(name="bboxes")
    fig_user = go.Figure(go.Bar(x=by_user["annotateur"], y=by_user["bboxes"]))
    fig_user.update_layout(title="Annotations par personne", height=320, margin=dict(l=20,r=20,t=40,b=20))

    by_image = df.groupby("image_id").size().reset_index(name="bboxes").sort_values("bboxes", ascending=False).head(20)
    fig_image = go.Figure(go.Bar(x=by_image["image_id"], y=by_image["bboxes"]))
    fig_image.update_layout(title="Top images (nombre d’annotations)", height=320, margin=dict(l=20,r=20,t=40,b=20))

    # Graphique IoU par image (simple comme les autres)
    by_iou = df.groupby("image_id")["annotateur"].nunique().reset_index()
    by_iou = by_iou[by_iou["annotateur"] >= 2].head(20)  # Images avec 2+ annotateurs
    fig_iou = go.Figure(go.Bar(x=by_iou["image_id"], y=[0.75] * len(by_iou)))  # Valeur exemple
    fig_iou.update_layout(title="IoU par image", height=320, margin=dict(l=20,r=20,t=40,b=20))

    return str(total_images), str(images_annot), str(total_bboxes), str(nb_users), fig_user, fig_image, fig_iou

# =========================
# 9) QUALITÉ (callbacks avec tri)
# =========================
@app.callback(
    Output("qual-table", "children"),
    Input("router", "pathname"),
    Input("store-qual-sort", "data"),
)
def populate_quality(pathname, sort_state):
    if pathname != "/qualite":
        raise PreventUpdate
    return build_quality_rows(sort_state or {"col":"image","asc":True})

@app.callback(
    Output("store-qual-sort", "data"),
    Input({"type":"qual-sort","col": ALL}, "n_clicks"),
    State("store-qual-sort", "data"),
    prevent_initial_call=True,
)
def change_quality_sort(clicks, sort_state):
    if not clicks or sum(1 for c in clicks if c) == 0:
        raise PreventUpdate
    trig = ctx.triggered_id
    if not isinstance(trig, dict) or "col" not in trig:
        raise PreventUpdate
    col_clicked = trig["col"]
    current = sort_state or {"col":"image","asc":True}
    if current["col"] == col_clicked:
        return {"col": col_clicked, "asc": (not bool(current.get("asc", True)))}
    return {"col": col_clicked, "asc": True}

# click sur image -> ouvre Annoter sur l’image
@app.callback(
    Output("store-pending-image", "data", allow_duplicate=True),
    Output("router", "href", allow_duplicate=True),
    Input({"type":"qual-img","image_id": ALL}, "n_clicks"),
    State({"type":"qual-img","image_id": ALL}, "id"),
    prevent_initial_call=True,
)
def open_from_quality_img(clicks, ids):
    if not clicks or not ids:
        raise PreventUpdate
    for c, i in zip(clicks, ids):
        if c:
            return {"image": i["image_id"]}, "/annotate"
    raise PreventUpdate

# =========================
# 10) HISTORISATION (avec filtres)
# =========================
@dash.callback(
    Output('historisation-log', 'children'),
    Input('router', 'pathname'),
    Input('store-histo-filter', 'data'),
)
def display_modification_log(pathname, active_filter):
    if pathname != "/historique":
        raise PreventUpdate
    logs = _safe_read_history(HISTO_JSON)

    if logs is None:
        return html.Div([
            html.H3("📁 Fichier d’historique non trouvé", style={'textAlign': 'center', 'color': '#ff9800'}),
            html.P("Le fichier sera créé automatiquement lors de la première utilisation de l’application.",
                   style={'textAlign': 'center', 'color': '#666', 'fontStyle': 'italic'})
        ])

    if not logs:
        return html.Div([
            html.H3("🗒️ Aucun historique enregistré", style={'textAlign': 'center', 'color': '#999'}),
            html.P("Les actions apparaîtront ici dès que vous aurez commencé à utiliser l’application.",
                   style={'textAlign': 'center', 'color': '#666', 'fontStyle': 'italic'})
        ])

    counters = {"CONNEXION":0,"EFFACEMENT":0,"ANNOTATION":0,"AUTRES":0}
    for it in logs:
        k = it["action"]
        if k in counters: counters[k]+=1
        else: counters["AUTRES"]+=1

    def chip(label, action_key, count, color, active):
        base_style = {
            'display':'inline-block','margin':'8px 10px','padding':'6px 12px',
            'borderRadius':'20px','fontWeight':'600','cursor':'pointer',
            'border':'1px solid #e5e7eb','userSelect':'none'
        }
        if active:
            style = dict(base_style, **{'backgroundColor': color+'22', 'color': color, 'border': f'1px solid {color}'})
        else:
            style = dict(base_style, **{'backgroundColor':'#fff','color':color})
        return html.Span(
            f"{label} : {count}",
            id={'type':'histo-chip','action': action_key},
            n_clicks=0,
            style=style
        )

    chips = [
        chip("Tous", "__ALL__", sum(counters.values()), "#111827", active_filter=="__ALL__"),
        chip("🔐 Connexions", "CONNEXION", counters["CONNEXION"], ACTION_STYLE['CONNEXION']['color'], active_filter=="CONNEXION"),
        chip("✏️ Annotations", "ANNOTATION", counters["ANNOTATION"], ACTION_STYLE['ANNOTATION']['color'], active_filter=="ANNOTATION"),
        chip("️ Suppressions", "EFFACEMENT", counters["EFFACEMENT"], ACTION_STYLE['EFFACEMENT']['color'], active_filter=="EFFACEMENT"),
    ]
    if counters["AUTRES"] > 0:
        chips.append(chip("❓ Autres", "AUTRES", counters["AUTRES"], "#666666", active_filter=="AUTRES"))

    stats_section = html.Div(chips, style={
        'backgroundColor':'#fff','padding':'14px','borderRadius':'10px',
        'border':'1px solid #e5e7eb','marginBottom':'12px','textAlign':'center',
        'boxShadow':'0 4px 12px rgba(0,0,0,.04)'
    })

    header_list = [html.Hr(), html.H3("📝 Journal détaillé", style={'color': '#333', 'marginTop': '6px'})]

    if active_filter and active_filter != "__ALL__":
        logs = [it for it in logs if (it["action"] == active_filter) or
                (active_filter == "AUTRES" and it["action"] not in counters)]

    cards = []
    for i, it in enumerate(logs):
        style_map = ACTION_STYLE.get(it["action"], DEFAULT_STYLE)
        color = style_map["color"]; emoji = style_map["emoji"]
        formatted_time = it["_dt"].strftime("%d/%m/%Y %H:%M:%S") if it["_dt"] is not None else it["timestamp"]

        cards.append(
            html.Div([
                html.Div([
                    html.Span(f"{emoji} {it['action']}", style={'fontSize': '14px', 'fontWeight': 'bold', 'color': color}),
                    html.Span(f" • {formatted_time}", style={'fontSize': '12px', 'color': '#888', 'marginLeft': '8px'}),
                ], style={'marginBottom': '6px'}),
                html.Div([
                    html.Span("👤 ", style={'marginRight': '4px'}),
                    html.Span(it["user"], style={'fontWeight': '600', 'color': '#111827'}),
                    html.Span(" • 🖼️ ", style={'margin': '0 6px'}),
                    html.Span(it["image"], style={'color': '#374151'}),
                ], style={'marginBottom': '6px'}),
                html.Div([
                    html.Span("📝 ", style={'marginRight': '4px'}),
                    html.Span(it["details"], style={'fontSize': '13px', 'color': '#6b7280', 'fontStyle': 'italic'}),
                ])
            ], style={
                'padding':'10px','margin':'8px 0',
                'backgroundColor':'#fff' if i % 2 == 0 else '#f8fafc',
                'border':'1px solid #e5e7eb','borderRadius':'10px',
                'borderLeft': f'4px solid {color}'
            })
        )

    return [stats_section] + header_list + cards

@app.callback(
    Output('store-histo-filter', 'data'),
    Input({'type':'histo-chip','action': ALL}, 'n_clicks'),
    prevent_initial_call=True
)
def set_histo_filter(clicks):
    if not clicks or sum(1 for c in clicks if c) == 0:
        raise PreventUpdate
    trig = ctx.triggered_id
    if isinstance(trig, dict) and "action" in trig:
        return trig["action"]
    raise PreventUpdate

# =========================
# 11) NAV PREV/NEXT
# =========================
@app.callback(
    Output("image-select", "value", allow_duplicate=True),
    Input("btn-next", "n_clicks"),
    Input("btn-prev", "n_clicks"),
    State("image-select", "options"),
    State("image-select", "value"),
    State("router", "pathname"),
    prevent_initial_call=True,
)
def next_prev(n_next, n_prev, options, value, pathname):
    if pathname != "/annotate":
        raise PreventUpdate
    imgs = [opt["value"] for opt in (options or [])]
    if not imgs:
        raise PreventUpdate
    trig = ctx.triggered_id
    if trig == "btn-next":
        if value in imgs:
            idx = imgs.index(value); return imgs[(idx + 1) % len(imgs)]
        return imgs[0]
    if trig == "btn-prev":
        if value in imgs:
            idx = imgs.index(value); return imgs[(idx - 1) % len(imgs)]
        return imgs[-1]
    raise PreventUpdate

# =========================
# 12) JS clientside (unique)
# =========================
app.index_string = (app.index_string.replace(
    "</body>",
    """
<script>
window.dash_clientside = Object.assign({}, window.dash_clientside || {}, {
  clientside: {

    draftZoomManager: function(relayoutData, figure){
      try{
        if(!figure || !figure.layout){ return window.dash_clientside.no_update; }
        const layout = figure.layout;
        const shapes = Array.isArray(layout.shapes) ? layout.shapes.slice() : [];

        const fixed  = shapes.filter(s => s && s.editable === false);
        const drafts = shapes.filter(s => !s || s.editable !== false);

        let mutated = false;

        // 1) Un seul draft (le dernier) + passer en pan pour éviter le 2e enchaîné
        if (drafts.length > 0){
          const lastDraft = drafts[drafts.length - 1];
          const newShapes = fixed.concat([lastDraft]);
          if (JSON.stringify(newShapes) !== JSON.stringify(layout.shapes)){
            layout.shapes = newShapes;
            mutated = true;
          }
          if (layout.dragmode !== 'pan'){
            layout.dragmode = 'pan';
            mutated = true;
          }
        }

        // 2) Après zoom/pan, s'il n'y a plus de draft, remettre drawrect
        const looksLikeZoom = relayoutData && Object.keys(relayoutData).some(
          k => k.startsWith('xaxis.') || k.startsWith('yaxis.') || k.includes('.range[')
        );
        if (drafts.length === 0 && looksLikeZoom){
          if (layout.dragmode !== 'drawrect'){
            layout.dragmode = 'drawrect';
            mutated = true;
          }
        }

        return mutated ? figure : window.dash_clientside.no_update;
      }catch(e){
    
        return false;
      }
    },

    updateHasDraft: function(relayoutData, figure){
      try{
        if(!figure || !figure.layout){ return false; }
        const shapes = Array.isArray(figure.layout.shapes) ? figure.layout.shapes : [];
        const drafts = shapes.filter(s => !s || s.editable !== false);
        return drafts.length > 0;
      }catch(e){
        return false;
      }
    }
  }
});
</script>
</body>"""
))

# =========================
# 13) RUN
# =========================
if __name__ == "__main__":
    print(f"Images root: {IMAGES_ROOT}")
    app.run(debug=False, host="127.0.0.1", port=int(os.environ.get("PORT", 8050)))
